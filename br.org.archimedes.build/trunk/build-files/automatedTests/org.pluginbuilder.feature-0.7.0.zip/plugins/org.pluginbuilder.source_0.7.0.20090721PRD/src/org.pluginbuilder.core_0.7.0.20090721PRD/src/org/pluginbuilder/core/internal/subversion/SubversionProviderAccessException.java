/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.internal.subversion;

public class SubversionProviderAccessException extends Exception {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;
}
