/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.internal;

import java.io.IOException;
import java.io.Writer;
import java.text.MessageFormat;

import org.eclipse.core.resources.IProject;
import org.eclipse.team.core.RepositoryProvider;
import org.eclipse.team.internal.ccvs.core.CVSException;
import org.eclipse.team.internal.ccvs.core.CVSTeamProvider;
import org.pluginbuilder.core.Activator;

public class CVSMapFileWriter implements IPDEModelWriter {

  // example file content:
  // feature@org.pluginbuilder=HEAD,:ext:cvsserver.com:/cvsroot,,path/org.pluginbuilder
  private final static String templateLine = "{0}@{1}=HEAD,{2},,{3}";
  private Writer writer;

  public CVSMapFileWriter(Writer writer) {
    super();
    this.writer = writer;
  }

  public void writeFeature(String id, IProject project) throws IOException {
    write( "feature", id, project );
  }

  public void writeFragment(String id, IProject project) throws IOException {
    write( "fragment", id, project );
  }

  public void writePlugin(String id, IProject project) throws IOException {
    write( "plugin", id, project );
  }

  @SuppressWarnings("restriction")
  // Yes, we want to access the CVS provider information
  private void write(String typ, String id, IProject project) throws IOException {
    RepositoryProvider provider = RepositoryProvider.getProvider( project );
    if (!(provider instanceof CVSTeamProvider)) {
      throw new UnsupportedOperationException( "Project is not shared with cvs" );
    }
    CVSTeamProvider cvsprovider = (CVSTeamProvider) provider;
    try {
      String remoteLocation = cvsprovider.getRemoteLocation().getLocation( false );
      String module = cvsprovider.getCVSWorkspaceRoot().getLocalRoot().getFolderSyncInfo().getRepository();
      String line = MessageFormat.format( templateLine, new Object[] { typ, id, remoteLocation, module } );
      writer.write( line );
      writer.write( "\n" );
    } catch (CVSException e) {
      Activator.log( e );
    }
  }

  public void finish() throws IOException {
    writer.close();
  }
}
