/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.releases;

import java.util.Properties;

public class NamedConfiguration {

  private boolean isDirty;
  private String name;
  private Properties properties;

  public NamedConfiguration(final String name, final Properties properties) {
    super();
    this.name = name;
    this.properties = properties;
    this.isDirty = false;
  }

  public Properties getProperties() {
    return properties;
  }

  public void setProperties(final Properties properties) {
    this.properties = properties;
    isDirty = true;
  }

  public String getName() {
    return name;
  }

  public boolean equals(final Object obj) {
    boolean result;
    if (obj instanceof NamedConfiguration) {
      NamedConfiguration other = (NamedConfiguration) obj;
      result = other.getName() != null && other.getName().equals( this.getName() );
    } else {
      result = super.equals( obj );
    }
    return result;
  }

  public boolean isDirty() {
    return isDirty;
  }

  public Object clone() throws CloneNotSupportedException {
    NamedConfiguration result = (NamedConfiguration) super.clone();
    result.properties = (Properties) properties.clone();
    return result;
  }

  public void setDirty(boolean isDirty) {
    this.isDirty = isDirty;
  }
}
