/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.internal.webdav;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import org.apache.commons.httpclient.HttpException;
import org.apache.webdav.lib.WebdavResource;

public class CreateOrUpdateFile extends SyncCommand {

  private static SimpleDateFormat format;
  static {
    format = new SimpleDateFormat( "EEE, dd MMM yyyy HH:mm:ss z", Locale.ENGLISH );
    format.setTimeZone( TimeZone.getTimeZone( "GMT" ) );
  }
  protected final File localFile;

  public CreateOrUpdateFile(File localFile, WebdavResource resource) {
    super( resource );
    this.localFile = localFile;
  }

  @Override
  public boolean execute() throws WebDavSyncException {
    try {
      boolean success = resource.putMethod( localFile );
      if (!success) {
        return false;
      }
      return setLastModified();
    } catch (Exception e) {
      throw new WebDavSyncException( e );
    }
  }

  public boolean setLastModified() throws HttpException, IOException {
    Date lastModified = new Date( localFile.lastModified() );
    return resource.proppatchMethod( "getlastmodified", CreateOrUpdateFile.format.format( lastModified ), true );
  }

  @Override
  public String description() {
    return "Uploading " + resource.getPath();
  }
}
