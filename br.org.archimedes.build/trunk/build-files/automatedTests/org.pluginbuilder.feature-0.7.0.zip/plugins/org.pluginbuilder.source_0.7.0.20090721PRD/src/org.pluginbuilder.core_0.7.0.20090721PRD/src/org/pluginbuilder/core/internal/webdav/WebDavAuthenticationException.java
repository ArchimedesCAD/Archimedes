package org.pluginbuilder.core.internal.webdav;

public class WebDavAuthenticationException extends Exception {

  /**
   * 
   */
  private static final long serialVersionUID = -8818256352876750026L;

  public WebDavAuthenticationException(String message) {
    super( message );
  }
}
