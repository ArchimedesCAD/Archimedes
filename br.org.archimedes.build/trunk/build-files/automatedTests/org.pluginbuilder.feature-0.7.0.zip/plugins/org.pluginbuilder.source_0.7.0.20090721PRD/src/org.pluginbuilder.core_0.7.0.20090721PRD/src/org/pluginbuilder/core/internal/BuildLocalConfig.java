/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.internal;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IResourceDeltaVisitor;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.pluginbuilder.core.Activator;
import org.pluginbuilder.internal.core.smartproperties.SmartProperties;
import org.pluginbuilder.internal.core.smartproperties.SmartProperty;

public class BuildLocalConfig implements IResourceChangeListener, IResourceDeltaVisitor {

  private SmartProperties smartProperties;
  private IPath pathToBuildConfigFile;

  public BuildLocalConfig(IPath buildLocalConfigPath) {
    super();
    this.pathToBuildConfigFile = buildLocalConfigPath;
    ResourcesPlugin.getWorkspace().addResourceChangeListener( this );
    readProperties();
  }

  public String getBuildHome() throws CoreException {
    return getPropertyByName( "buildHome" ).getValue();
  }

  private SmartProperty getPropertyByName(String propertyName) throws CoreException {
    SmartProperty propertyByName = smartProperties.getPropertyByName( propertyName );
    if (propertyByName == null) {
      throw Activator.createCoreException( "Could not find property '" + propertyName + "' in build_local.properties." );
    }
    return propertyByName;
  }

  public void setBuildHome(String expectedBuildDir) {
    smartProperties.getPropertyByName( "buildHome" ).setValue( expectedBuildDir );
  }

  public String getBuildDirectory() throws CoreException {
    return getPropertyByName( "buildDirectory" ).getValue();
  }

  // public String getEclipseDir() {
  // return props.getProperty( "eclipseDir" );
  // }
  @Override
  protected void finalize() throws Throwable {
    super.finalize();
    ResourcesPlugin.getWorkspace().removeResourceChangeListener( this );
  }

  public boolean visit(final IResourceDelta delta) throws CoreException {
    if (delta != null) {
      IResourceDelta buildConfigDelta = delta.findMember( pathToBuildConfigFile );
      if (buildConfigDelta != null) {
        readProperties();
      }
    }
    return false;
  }

  private void readProperties() {
    IFile file = ResourcesPlugin.getWorkspace().getRoot().getFile( pathToBuildConfigFile );
    try {
      InputStream contents = file.getContents();
      smartProperties = new SmartProperties( contents );
      contents.close();
    } catch (Exception e) {
      Activator.log( e );
    }
  }

  public void resourceChanged(IResourceChangeEvent event) {
    if (event.getType() == IResourceChangeEvent.POST_CHANGE) {
      try {
        event.getDelta().accept( this );
      } catch (CoreException e) {
        Activator.log( e );
      }
    }
  }

  public void save(IProgressMonitor monitor) throws IOException, CoreException {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    smartProperties.write( byteArrayOutputStream );
    IFile file = ResourcesPlugin.getWorkspace().getRoot().getFile( pathToBuildConfigFile );
    file.setContents( new ByteArrayInputStream( byteArrayOutputStream.toByteArray() ), true /* force */,
        true /* keepHistory */, monitor );
  }

  public SmartProperties getSmartProperties() {
    return smartProperties;
  }

}
