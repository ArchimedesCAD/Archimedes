/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.internal;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Preferences;
import org.pluginbuilder.autotestsuite.junit3.AllTestSuite;
import org.pluginbuilder.autotestsuite.junit3.AutoTestSuite;
import org.pluginbuilder.autotestsuite.junit3.InclusionFilter;
import org.pluginbuilder.core.Activator;
import org.pluginbuilder.core.releases.CollectionUtil;
import org.pluginbuilder.internal.core.smartproperties.SmartProperties;

public class BuildConfigPersistency {

  public static final String BUILD_PROPERTIES_FILE = "build-files/build.properties";
  public static final String RCP_BUILD_PROPERTIES_FILE = "build-files/build_rcp.properties";
  public static final String TEST_PROPERTIES_FILE = "build-files/automatedTests/run-tests.properties";
  public static final String BUILD_FILE = "pluginbuilder.config";
  public static final String BUILD_LOCAL_FILE = "build_local.properties";
  private static final String FEATURES = "pluginbuilder.features";
  private static final String IS_SVN = "pluginbuilder.is.svn";
  private static final String IS_CVS = "pluginbuilder.is.cvs";
  private static final String IS_COPY = "pluginbuilder.is.copy";
  private static final String SVN_URL = "pluginbuilder.svn.url";
  private static final String SVN_USER = "pluginbuilder.svn.user";
  private static final String SVN_PASSWORD = "pluginbuilder.svn.password";
  private static final String SERVER_USER = "pluginbuilder.server.user";
  private static final String IS_RUN_TESTS = "pluginbuilder.is.runtests";
  private static final String TEST_ECLIPSE_ZIP = "test.eclipse.zip";
  private static final String ECLIPSE_URL = "pluginbuilder.eclipse.url";
  private static final String ANT_VERBOSE = "verboseAnt";
  private static final String IS_RCP_BUILD = "pluginbuilder.is.rcpbuild";
  private static final String FEATURE_URLS = "pluginbuilder.feature.urls";
  private static final String IS_GENERATION_NECESSARY = "pluginbuilder.is.generation.necessary";

  public static BuildConfig read(IProject project) {
    BuildConfig result = new BuildConfig();
    IFile file = project.getFile( BUILD_FILE );
    if (file.exists()) {
      Properties properties = new Properties();
      try {
        properties.load( file.getContents() );
        new BuildConfigPersistency().read( result, properties );
      } catch (Exception e) {
        Activator.log( e );
      }
      IPath buildLocalConfigPath = project.getFile( BUILD_LOCAL_FILE ).getFullPath();
      result.setBuildLocalConfig( new BuildLocalConfig( buildLocalConfigPath ) );
      IFile buildProperties = project.getFile( BUILD_PROPERTIES_FILE );
      result.setBuildProperties( readBuildProperties( buildProperties ) );
      IFile rcpBuildProperties = project.getFile( RCP_BUILD_PROPERTIES_FILE );
      result.setRcpBuildProperties( readBuildProperties( rcpBuildProperties ) );
      IFile runTestsProperties = project.getFile( TEST_PROPERTIES_FILE );
      result.setTestProperties( readBuildProperties( runTestsProperties ) );
    }
    return result;
  }

  private static SmartProperties readBuildProperties(IFile buildProperties) {
    SmartProperties smartProperties = null;
    try {
      InputStream contents = buildProperties.getContents();
      smartProperties = new SmartProperties( contents );
      contents.close();
    } catch (Exception e) {
      Activator.log( e );
    }
    return smartProperties;
  }

  public static void write(BuildConfig buildConfig, IProject project, IProgressMonitor monitor) throws IOException {
    IFile file = project.getFile( BUILD_FILE );
    if (file.exists()) {
      Preferences preferences = new Preferences();
      BuildConfig savedBuildConfig = read( project );
      new BuildConfigPersistency().write( buildConfig, preferences, savedBuildConfig );
      ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
      preferences.store( outputStream, null );
      String propsAsString = new String( outputStream.toByteArray() );
      try {
        file.setContents( new ByteArrayInputStream( propsAsString.getBytes() ), true /* force */,
            true /* keepHistory */, monitor );
      } catch (CoreException e) {
        Activator.log( e );
      }
      IFile buildProperties = project.getFile( BUILD_PROPERTIES_FILE );
      writeBuildProperties( buildProperties, buildConfig.getBuildProperties(), monitor );
      buildProperties = project.getFile( RCP_BUILD_PROPERTIES_FILE );
      writeBuildProperties( buildProperties, buildConfig.getRcpBuildProperties(), monitor );
      buildProperties = project.getFile( TEST_PROPERTIES_FILE );
      writeBuildProperties( buildProperties, buildConfig.getTestProperties(), monitor );
    }
  }

  private static void writeBuildProperties(IFile buildProperties, SmartProperties buildProperties2,
      IProgressMonitor monitor) {
    try {
      ByteArrayOutputStream buildPropertiesOutputStream = new ByteArrayOutputStream();
      buildProperties2.write( buildPropertiesOutputStream );
      buildProperties.setContents( new ByteArrayInputStream( buildPropertiesOutputStream.toByteArray() ),
          true /* force */, true /* keepHistory */, monitor );
    } catch (Exception e) {
      Activator.log( e );
    }
  }

  public void write(BuildConfig buildConfig, Preferences prefs, BuildConfig savedBuildConfig) {
    prefs.setValue( FEATURES, CollectionUtil.serializeList( buildConfig.getFeatures() ) );
    prefs.setValue( IS_SVN, Boolean.toString( buildConfig.isSVN() ) );
    prefs.setValue( IS_CVS, Boolean.toString( buildConfig.isCVS() ) );
    prefs.setValue( IS_COPY, Boolean.toString( buildConfig.isCopy() ) );
    if (buildConfig.getSvnUrl() != null) {
      prefs.setValue( SVN_URL, buildConfig.getSvnUrl() );
    }
    if (buildConfig.getSvnUser() != null) {
      prefs.setValue( SVN_USER, buildConfig.getSvnUser() );
    }
    if (buildConfig.getSvnPassword() != null) {
      prefs.setValue( SVN_PASSWORD, buildConfig.getSvnPassword() );
    }
    if (buildConfig.getServerUser() != null) {
      prefs.setValue( SERVER_USER, buildConfig.getServerUser() );
    }
    if (buildConfig.isAntVerbose()) {
      prefs.setValue( ANT_VERBOSE, "-verbose" );
    }
    prefs.setValue( AllTestSuite.AUTOTEST_PLUGIN_INCLUSIONS, buildConfig.getPluginInclusionFilter()
        .serializeIncludePatterns() );
    prefs.setValue( AllTestSuite.AUTOTEST_PLUGIN_EXCLUSIONS, buildConfig.getPluginInclusionFilter()
        .serializeExcludePatterns() );
    prefs.setValue( AutoTestSuite.AUTOTEST_CLASS_INCLUSIONS, buildConfig.getTestInclusionFilter()
        .serializeIncludePatterns() );
    prefs.setValue( AutoTestSuite.AUTOTEST_CLASS_EXCLUSIONS, buildConfig.getTestInclusionFilter()
        .serializeExcludePatterns() );
    prefs.setValue( IS_RUN_TESTS, Boolean.toString( buildConfig.isRunTests() ) );
    if (buildConfig.getTestEclipseZip() != null) {
      prefs.setValue( TEST_ECLIPSE_ZIP, buildConfig.getTestEclipseZip() );
    }

    if (buildConfig.getEclipseUrl() != null) {
      prefs.setValue( ECLIPSE_URL, buildConfig.getEclipseUrl() );
    }
    prefs.setValue( FEATURE_URLS, CollectionUtil.serializeList( buildConfig.getFeatureUrls() ) );
    prefs.setValue( IS_RCP_BUILD, Boolean.toString( buildConfig.isRcpBuild() ) );
    boolean isGenerationNecessary = buildConfig.isGenerationNecessary();
    if (!isGenerationNecessary) {
      boolean changes = !savedBuildConfig.getFeatures().equals( buildConfig.getFeatures() );
      if (!changes) {
        changes = !savedBuildConfig.getFetchMode().equals( buildConfig.getFetchMode() );
      }
      if (!changes && buildConfig.isSVN()) {
        // the svn URL is both used at runtime (i.e. as Property in an ANT script)
        // and at generation time (if there is no subversion/suclipse provider)
        changes = !equals_( savedBuildConfig.getSvnUrl(), buildConfig.getSvnUrl() );
      }
      // SVN User and Password are only used at runtime, so we do not want have to re-generate
      // after they have changed
      isGenerationNecessary = changes;
    }
    buildConfig.setGenerationNecessary( isGenerationNecessary );
    prefs.setValue( IS_GENERATION_NECESSARY, isGenerationNecessary );
  }

  private boolean equals_(String a, String b) {
    boolean result = a == null && b == null;
    if (!result) {
      result = a != null && b != null && a.equals( b );
    }
    return result;
  }

  public void read(BuildConfig buildConfig, Properties props) {
    CollectionUtil.deserializeList( props.getProperty( FEATURES ), buildConfig.getFeatures() );
    readFetchMethod( buildConfig, props );
    buildConfig.setSvnUrl( props.getProperty( SVN_URL ) );
    buildConfig.setSvnUser( props.getProperty( SVN_USER ) );
    buildConfig.setSvnPassword( props.getProperty( SVN_PASSWORD ) );
    buildConfig.setServerUser( props.getProperty( SERVER_USER ) );
    buildConfig.setAntVerbose( props.getProperty( ANT_VERBOSE ) != null );
    String pluginInclusionList = props.getProperty( AllTestSuite.AUTOTEST_PLUGIN_INCLUSIONS );
    if (pluginInclusionList == null) {
      pluginInclusionList = AllTestSuite.AUTOTEST_PLUGIN_DEFAULT_INCLUSIONS;
    }
    String pluginExclusionList = props.getProperty( AllTestSuite.AUTOTEST_PLUGIN_EXCLUSIONS );
    if (pluginExclusionList == null) {
      pluginExclusionList = AllTestSuite.AUTOTEST_PLUGIN_DEFAULT_EXCLUSIONS;
    }
    buildConfig.setPluginInclusionFilter( new InclusionFilter( pluginInclusionList, pluginExclusionList ) );
    String testInclusionList = props.getProperty( AutoTestSuite.AUTOTEST_CLASS_INCLUSIONS );
    if (testInclusionList == null) {
      testInclusionList = AutoTestSuite.AUTOTEST_CLASS_DEFAULT_INCLUSIONS;
    }
    String testExclusionList = props.getProperty( AutoTestSuite.AUTOTEST_CLASS_EXCLUSIONS );
    if (testExclusionList == null) {
      testExclusionList = AutoTestSuite.AUTOTEST_CLASS_DEFAULT_EXCLUSIONS;
    }
    buildConfig.setTestInclusionFilter( new InclusionFilter( testInclusionList, testExclusionList ) );
    buildConfig.setRunTests( getBoolean( props, IS_RUN_TESTS ) );
    buildConfig.setTestEclipseZip( props.getProperty( TEST_ECLIPSE_ZIP ) );
    buildConfig.setEclipseUrl( props.getProperty( ECLIPSE_URL ) );
    buildConfig.setRcpBuild( getBoolean( props, IS_RCP_BUILD ) );
    CollectionUtil.deserializeList( props.getProperty( FEATURE_URLS ), buildConfig.getFeatureUrls() );
    buildConfig.setGenerationNecessary( getBoolean( props, IS_GENERATION_NECESSARY ) );
  }

  private void readFetchMethod(BuildConfig buildConfig, Properties props) {
    // 1. Ensure consistency
    Boolean isSVN = getBooleanObject( props, IS_SVN );
    Boolean isCVS = getBooleanObject( props, IS_CVS );
    Boolean isCopy = getBooleanObject( props, IS_COPY );
    boolean isInconsistent = true;
    if (isTrue( isCVS )) {
      isInconsistent = isTrue( isSVN ) || isTrue( isCopy );
    } else if (isTrue( isSVN )) {
      isInconsistent = isTrue( isCVS ) || isTrue( isCopy );
    } else if (isTrue( isCopy )) {
      isInconsistent = isTrue( isCVS ) || isTrue( isSVN );
    }
    // 2. set only if consistent, otherwise the default UNKNOWN will be used
    if (!isInconsistent) {
      if (isTrue( isCVS )) {
        buildConfig.setCVS();
      } else if (isTrue( isSVN )) {
        buildConfig.setSVN();
      } else if (isTrue( isCopy )) {
        buildConfig.setCopy();
      }
    }
  }

  private boolean isTrue(Boolean bool) {
    return bool != null && bool.booleanValue();
  }

  protected boolean getBoolean(Properties props, String key) {
    boolean result = false;
    String strValue = (String) props.get( key );
    if (strValue != null) {
      result = strValue.trim().toLowerCase().equals( "true" );
    }
    return result;
  }

  protected Boolean getBooleanObject(Properties props, String key) {
    Boolean result = null;
    String strValue = (String) props.get( key );
    if (strValue != null) {
      result = Boolean.parseBoolean( strValue );
    }
    return result;
  }
}
