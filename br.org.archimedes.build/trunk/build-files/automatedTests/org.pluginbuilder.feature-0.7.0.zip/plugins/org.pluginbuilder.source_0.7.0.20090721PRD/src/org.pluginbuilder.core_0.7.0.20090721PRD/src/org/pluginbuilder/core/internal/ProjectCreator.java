/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.internal;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Enumeration;
import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.osgi.service.datalocation.Location;
import org.osgi.framework.Bundle;
import org.pluginbuilder.core.Activator;
import org.pluginbuilder.core.ProjectNature;
import org.pluginbuilder.core.internal.templates.Template;
import org.pluginbuilder.core.internal.templates.TemplateNotFoundException;
import org.pluginbuilder.internal.core.smartproperties.SmartProperties;
import org.pluginbuilder.internal.core.smartproperties.SmartProperty;
import org.pluginbuilder.util.FileCopy;

public class ProjectCreator implements IWorkspaceRunnable {

  private IPath projectLocation;
  private static final String BUILD_LOCAL = "build_local.properties";
  private static final String TEMPLATE_LOCATION = "/templates/initialProjectSetup";
  private String name;

  public static String getBuildHome(IProject project) {
    return Activator.escapePath( project.getLocation().toOSString() );
  }

  public void run(IProgressMonitor monitor) throws CoreException {
    IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
    IProject resourcesProject = root.getProject( name );
    if (projectLocation != null) {
      IWorkspace workspace = ResourcesPlugin.getWorkspace();
      final IProjectDescription description = workspace.newProjectDescription( resourcesProject.getName() );
      description.setLocation( projectLocation );
      resourcesProject.create( description, monitor );
    } else {
      resourcesProject.create( monitor );
    }
    resourcesProject.open( monitor );
    IProjectDescription description = resourcesProject.getDescription();
    String[] natures = new String[] { ProjectNature.NATURE_ID };
    description.setNatureIds( natures );
    resourcesProject.setDescription( description, monitor );
    try {
      copyTemplates( monitor, resourcesProject );
      createBuildLocalTemplate( monitor, resourcesProject );
      Template allElements = createInitialAllElementsTemplate();
      allElements.write( resourcesProject );
    } catch (Exception e) {
      throw Activator.createCoreException( e );
    }
  }

  @SuppressWarnings("unchecked")
  private void copyTemplates(IProgressMonitor monitor, IProject resourcesProject) throws CoreException, IOException {
    final File dstDir = resourcesProject.getLocation().toFile();
    final Bundle bundle = Activator.getDefault().getBundle();
    final Enumeration<URL> entries = bundle.findEntries(TEMPLATE_LOCATION, null, true);
    if (entries == null) {
      final String message = "Error copying templates. Core bundle entries for project setup templates could not be found";
      throw Activator.createCoreException( message );
    }
    while (entries.hasMoreElements()) {
      final URL entry = entries.nextElement();
      final String path = entry.getPath();
      final File destination = new File(dstDir, path.substring(TEMPLATE_LOCATION.length()));
      
      final File directory;
      boolean pathRepresentsFile = !path.endsWith("/");
      if (pathRepresentsFile) {
        directory = destination.getParentFile();
      } else {
        directory = destination;
      }
      // create directory and any missing intermediate directories
      directory.mkdirs();
      
      if (pathRepresentsFile) {
        // copy entry
        FileCopy.copyStreamToFile(entry.openStream(), destination);
      }
    }
    resourcesProject.refreshLocal( IResource.DEPTH_INFINITE, monitor );
  }
  
  public void createBuildLocalTemplate(IProgressMonitor monitor, IProject resourcesProject) throws CoreException,
      IOException {
    String eclipseDir = "Could not be determined automatically";
    Location installLocation = Platform.getInstallLocation();
    if (installLocation != null) {
      URL url = installLocation.getURL();
      if (url != null) {
        eclipseDir = new Path( url.getPath() ).toPortableString();
      }
    }
    String buildDirectory = null;
    String tmpLocation = System.getProperty( "java.io.tmpdir" );
    // TODO: write validator for build_local.properties!
    if (tmpLocation == null || !new File( tmpLocation ).exists()) {
      buildDirectory = "could not acquire java.tmp.dir";
    } else {
      buildDirectory = new File( new File( tmpLocation, "pluginbuilder" ), resourcesProject.getName() )
          .getAbsolutePath();
    }
    IFile buildLocal = resourcesProject.getFile( new Path( BUILD_LOCAL ) );
    SmartProperties smartProperties = new SmartProperties( buildLocal.getContents() );
    List<SmartProperty> allProperties = smartProperties.getAllProperties();
    for (SmartProperty smartProperty : allProperties) {
      if (smartProperty.getName().equals( "buildHome" )) {
        smartProperty.setValue( Activator.escapePath( ProjectCreator.getBuildHome( resourcesProject ) ) );
      } else if (smartProperty.getName().equals( "eclipseDir" )) {
        smartProperty.setValue( Activator.escapePath( eclipseDir ) );
      } else if (smartProperty.getName().equals( "buildDirectory" )) {
        smartProperty.setValue( Activator.escapePath( buildDirectory ) );
      } else if (smartProperty.getName().equals( "os" )) {
        smartProperty.setValue( Platform.getOS() );
      } else if (smartProperty.getName().equals( "ws" )) {
        smartProperty.setValue( Platform.getWS() );
      } else if (smartProperty.getName().equals( "arch" )) {
        smartProperty.setValue( Platform.getOSArch() );
      }
    }
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    smartProperties.write( baos );
    buildLocal.setContents( new ByteArrayInputStream( baos.toByteArray() ), true /* force */,
        true /* keep history */, monitor );
  }

  public Template createInitialAllElementsTemplate() throws TemplateNotFoundException {
    Template template = Template.createTemplate( new Path( "build-files/allElements.xml" ) );
    String failTask = "        <fail message=\"Please generate files with the Plugin Builder Editor before starting the build.\"/>";
    template.replace( "@delegates@", failTask );
    template.replace( "@assembleTargets@", "" );
    return template;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public IPath getProjectLocation() {
    return projectLocation;
  }

  public void setProjectLocation(IPath projectLocation) {
    this.projectLocation = projectLocation;
  }
}
