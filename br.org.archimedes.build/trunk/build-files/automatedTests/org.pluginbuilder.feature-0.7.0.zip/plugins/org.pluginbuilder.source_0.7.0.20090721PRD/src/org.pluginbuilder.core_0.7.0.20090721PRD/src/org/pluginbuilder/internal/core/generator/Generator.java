/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld This program is distributed under the
 * Eclipse Public License v1.0 which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 ******************************************************************************/
package org.pluginbuilder.internal.core.generator;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.Path;
import org.eclipse.pde.internal.core.ifeature.IFeature;
import org.pluginbuilder.core.Activator;
import org.pluginbuilder.core.internal.BuildConfig;
import org.pluginbuilder.core.internal.CVSMapFileWriter;
import org.pluginbuilder.core.internal.CopyMapFileWriter;
import org.pluginbuilder.core.internal.IPDEModelWriter;
import org.pluginbuilder.core.internal.PDEModel;
import org.pluginbuilder.core.internal.SvnFetchAllFileWriter;
import org.pluginbuilder.core.internal.templates.Template;
import org.pluginbuilder.core.internal.templates.TemplateNotFoundException;

public class Generator {

  BuildConfig buildConfig;
  PDEModel pdeModel;

  public Generator(BuildConfig buildConfig) {
    this.buildConfig = buildConfig;
    pdeModel = new PDEModel();
  }

  protected List<IFeature> getFeatures() {
    // TODO: move to buildConfig ?
    List<IFeature> features = new ArrayList<IFeature>();
    List<String> featureIds = buildConfig.getFeatures();
    for (String featureId : featureIds) {
      IFeature feature = pdeModel.findFeature( featureId );
      if (feature == null) {
        throw new RuntimeException( "Feature not found: " + featureId );
      }
      features.add( feature );
    }
    return features;
  }

  public String generateFetchSvnAll() {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    SvnFetchAllFileWriter svnFetchAllFileWriter = new SvnFetchAllFileWriter( new OutputStreamWriter( baos ),
        buildConfig );
    try {
      pdeModel.writeFeatures( getFeatures(), svnFetchAllFileWriter );
    } catch (IOException e) {
      // Ignore since writing to byte array
    }
    return new String( baos.toByteArray() );
  }

  public String generateMapFile(boolean isCVS) {
    StringWriter writer = new StringWriter();
    IPDEModelWriter mapFileWriter = isCVS ? new CVSMapFileWriter( writer ) : new CopyMapFileWriter( writer );
    try {
      pdeModel.writeFeatures( getFeatures(), mapFileWriter );
    } catch (IOException e) {
      // Ignore since writing to byte array
    }
    return writer.toString();
  }

  public Template createAllElements() throws TemplateNotFoundException {
    String allElementsFile = "build-files/allElements.xml";
    Activator.logInfo( "Creating " + allElementsFile );
    Template allElementsTemplate = Template.createTemplate( new Path( allElementsFile ) );
    StringBuffer delegates = new StringBuffer();
    StringBuffer assembleTargets = new StringBuffer();
    for (String featureId : buildConfig.getFeatures()) {
      createAllElementsEntries( featureId, delegates, assembleTargets );
    }
    allElementsTemplate.replace( "@delegates@", delegates.toString() );
    allElementsTemplate.replace( "@assembleTargets@", assembleTargets.toString() );
    return allElementsTemplate;
  }

  private void createAllElementsEntries(String featureId, StringBuffer delegates, StringBuffer assembleTargets)
      throws TemplateNotFoundException {
    Activator.logInfo( " adding feature " + featureId );
    createAllElementsDelegateForFeature( featureId, delegates );
    createAssembleTargetsForFeature( featureId, assembleTargets );
  }

  private void createAllElementsDelegateForFeature(String featureId, StringBuffer delegates)
      throws TemplateNotFoundException {
    Template delegate = Template.createTemplate( new Path( "build-files/allElementsDelegate.part" ) );
    delegate.reset();
    delegate.replace( "@feature@", featureId );
    delegates.append( delegate.getSubsitutedContent() );
  }

  private void createAssembleTargetsForFeature(String featureId, StringBuffer assembleTargets)
      throws TemplateNotFoundException {
    Template assembleTarget = Template.createTemplate( new Path( "build-files/allElementsAssembleTarget.part" ) );
    assembleTarget.replace( "@feature@", featureId );
    assembleTargets.append( assembleTarget.getSubsitutedContent() );
  }
}
