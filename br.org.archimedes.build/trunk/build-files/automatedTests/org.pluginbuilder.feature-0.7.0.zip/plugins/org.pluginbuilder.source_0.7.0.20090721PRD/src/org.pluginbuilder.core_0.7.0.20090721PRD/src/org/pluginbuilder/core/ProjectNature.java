/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectNature;
import org.eclipse.core.runtime.CoreException;

public class ProjectNature implements IProjectNature {

  // ID (String) for the identification of the Project nature.
  public final static String NATURE_ID = Activator.getDefault().getBundle().getSymbolicName() + ".pluginBuilderNature";

  public void configure() throws CoreException {
    // TODO Auto-generated method stub
  }

  public void deconfigure() throws CoreException {
    // TODO Auto-generated method stub
  }

  public IProject getProject() {
    // TODO Auto-generated method stub
    return null;
  }

  public void setProject(IProject project) {
    // TODO Auto-generated method stub
  }
}
