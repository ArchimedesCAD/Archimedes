/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.internal;

import java.io.IOException;
import java.io.Writer;
import java.text.MessageFormat;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.IPath;

public class CopyMapFileWriter implements IPDEModelWriter {

  // example file content:
  // feature@org.pluginbuilder=COPY,baseDir,path/org.pluginbuilder
  private final static String templateLine = "{0}@{1}=COPY,{2},{3}";
  private Writer writer;

  public CopyMapFileWriter(Writer writer) {
    super();
    this.writer = writer;
  }

  public void writeFeature(String id, IProject project) throws IOException {
    write( "feature", id, project );
  }

  public void writeFragment(String id, IProject project) throws IOException {
    write( "fragment", id, project );
  }

  public void writePlugin(String id, IProject project) throws IOException {
    write( "plugin", id, project );
  }

  private void write(String typ, String id, IProject project) throws IOException {
    IPath absoluteLocation = project.getLocation();
    IPath absoluteWorkspaceLocation = project.getWorkspace().getRoot().getLocation();
    String baseDir = null;
    String filePath = null;
    int firstMatchingSegments = absoluteWorkspaceLocation.matchingFirstSegments( absoluteLocation );
    if (firstMatchingSegments == absoluteWorkspaceLocation.segmentCount()) {
      baseDir = absoluteWorkspaceLocation.toPortableString();
      filePath = absoluteLocation.removeFirstSegments( firstMatchingSegments ).setDevice( null ).toPortableString();
    } else {
      baseDir = absoluteLocation.removeLastSegments( 1 ).toPortableString();
      filePath = absoluteLocation.lastSegment();
    }
    String line = MessageFormat.format( templateLine, new Object[] { typ, id, baseDir, filePath } );
    writer.write( line );
    writer.write( "\n" );
  }

  public void finish() throws IOException {
    writer.close();
  }
}
