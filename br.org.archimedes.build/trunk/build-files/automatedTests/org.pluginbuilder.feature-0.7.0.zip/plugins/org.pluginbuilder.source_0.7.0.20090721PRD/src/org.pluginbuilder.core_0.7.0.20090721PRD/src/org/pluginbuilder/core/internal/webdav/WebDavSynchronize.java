/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.internal.webdav;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.HttpURL;
import org.apache.commons.httpclient.URIException;
import org.apache.commons.httpclient.util.URIUtil;
import org.apache.webdav.lib.WebdavResource;
import org.pluginbuilder.core.Activator;

public class WebDavSynchronize {

  private WebdavResource baseResource;
  private final File localDir;
  private HttpURL baseUrl;
  private String baseUrlPath;
  private Pattern excludePattern;

  public WebDavSynchronize(String url, String user, String password, File localDir) throws WebDavSyncException,
      WebDavAuthenticationException {
    this.localDir = localDir;
    try {
      baseUrl = new HttpURL( url );
      baseUrl.setUserinfo( user, password );
      baseUrlPath = baseUrl.getPath();
      baseResource = getResource( "" );
    } catch (Exception e) {
      Activator.log( e );
      throw new WebDavSyncException( e.getMessage() );
    }
    switch (baseResource.getStatusCode()) {
    case HttpStatus.SC_UNAUTHORIZED:
      String message = "Could not authenticate user " + user + " at " + url;
      throw new WebDavAuthenticationException( message );
    case HttpStatus.SC_OK:
    case HttpStatus.SC_MULTI_STATUS:
      break;
    default:
      message = "An error occurred while accessing " + url + ". " + baseResource.getStatusMessage();
      throw new WebDavSyncException( message );
    }
  }

  public List<SyncCommand> createSyncCommands() throws WebDavSyncException {
    List<SyncCommand> commands = new ArrayList<SyncCommand>();
    try {
      createSyncCommands( localDir, commands );
      createDeleteCommands( baseResource, commands );
    } catch (Exception e) {
      throw new WebDavSyncException( e );
    }
    return commands;
  }

  private void createSyncCommands(File dir, List<SyncCommand> commandCollector) throws HttpException, IOException {
    File[] listFiles = dir.listFiles();
    for (int i = 0; i < listFiles.length; i++) {
      File currentFile = listFiles[i];
      String path = getRelativePath( currentFile );
      if (isExcluded( path )) {
        continue;
      }
      WebdavResource resource = getResource( path );
      createCommand( currentFile, resource, commandCollector );
      if (currentFile.isDirectory()) {
        createSyncCommands( currentFile, commandCollector );
      }
    }
  }

  private boolean isExcluded(String path) {
    return excludePattern != null && excludePattern.matcher( path ).matches();
  }

  private String getRelativePath(File currentFile) {
    String fullPath = currentFile.getAbsolutePath();
    assert (fullPath.startsWith( localDir.getAbsolutePath() ));
    String path = fullPath.substring( localDir.getAbsolutePath().length() );
    return path.replaceAll( "[\\\\]", "/" );
  }

  @SuppressWarnings("unchecked")
  private void createDeleteCommands(WebdavResource remotedir, List<SyncCommand> commandCollector) throws HttpException,
      IOException {
    // depth search
    Enumeration resources = remotedir.getChildResources().getResources();
    while (resources.hasMoreElements()) {
      WebdavResource resource = (WebdavResource) resources.nextElement();
      if (resource.isCollection()) {
        createDeleteCommands( resource, commandCollector );
      }
      File local = getLocal( resource );
      // exclude only files, excluding folders would become complicated
      // if folders in the middle of a hierachy matched
      if (!resource.isCollection()) {
        String path = getRelativePath( local );
        if (isExcluded( path )) {
          continue;
        }
      }
      if (!local.exists()) {
        commandCollector.add( new DeleteResource( resource ) );
      }
    }
  }

  private void createCommand(File file, WebdavResource resource, List<SyncCommand> commandCollector) throws IOException {
    assert (file.exists());
    if (file.isDirectory()) {
      if (!resource.exists()) {
        commandCollector.add( new CreateFolder( resource ) );
      } else if (!resource.isCollection()) {
        commandCollector.add( new DeleteResource( resource ) );
        commandCollector.add( new CreateFolder( resource ) );
      }
    } else {
      if (!resource.exists()) {
        commandCollector.add( new CreateOrUpdateFile( file, resource ) );
      } else if (resource.isCollection()) {
        commandCollector.add( new DeleteResource( resource ) );
        commandCollector.add( new CreateOrUpdateFile( file, resource ) );
      } else {
        // the milliseconds are not considered in httpdate
        long fileLastModifiedMillis = file.lastModified() % 1000;
        if (file.lastModified() - resource.getGetLastModified() != fileLastModifiedMillis) {
          commandCollector.add( new CreateOrUpdateFile( file, resource ) );
        }
      }
    }
  }

  /**
   * 
   * @param path
   *          relative path starting with /. Must contain slashes, no
   *          backslashes allowed.
   * @return
   * @throws HttpException
   * @throws URIException
   * @throws IOException
   */
  private WebdavResource getResource(String path) throws HttpException, URIException, IOException {
    String newPath = baseUrlPath;
    if (path != null && path.length() > 0) {
      newPath = newPath + path;
    }
    String[] splitString = newPath.split("/") ;
    StringBuffer encoded = new StringBuffer() ;
    for (int i = 0; i < splitString.length; i++) {
    	if (splitString[i].length() == 0) {
    		continue ;
    	}
		encoded.append("/") ;
		encoded.append(URIUtil.encodePath(splitString[i], "US-ASCII"));
	}
    // The problem with filenames with invalid chars (those which must be encoded)
    // is that the webdav lib does not handle them correctly itself. I.e. we get
    // an exception from the webdav lib if we check for delete commands.
    if (!encoded.toString().equals(newPath)) {
    	String message = "Resource contains 'invalid' chars: " + newPath ;
    	throw new URIException(message) ;
    }
    return new WebdavResource( new HttpURL( baseUrl, newPath ));
  }

  private File getLocal(WebdavResource resource) throws URIException {
    String path = resource.getPath();
    assert (path.startsWith( baseUrlPath ));
    return new File( localDir, path.substring( baseUrlPath.length() ) );
  }

  public void setExcludePattern(Pattern excludePattern) {
    this.excludePattern = excludePattern;
  }
}
