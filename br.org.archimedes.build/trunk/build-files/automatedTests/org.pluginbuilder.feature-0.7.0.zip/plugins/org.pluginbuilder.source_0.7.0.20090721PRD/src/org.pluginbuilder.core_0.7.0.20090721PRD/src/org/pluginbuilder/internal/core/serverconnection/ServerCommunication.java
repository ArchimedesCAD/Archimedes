/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.internal.core.serverconnection;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpMethodBase;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.Platform;
import org.pluginbuilder.core.Activator;
import org.pluginbuilder.core.internal.webdav.SyncCommand;
import org.pluginbuilder.core.internal.webdav.WebDavAuthenticationException;
import org.pluginbuilder.core.internal.webdav.WebDavSyncException;
import org.pluginbuilder.core.internal.webdav.WebDavSynchronize;

public class ServerCommunication {

  private static final String UPLOAD_PART_NAME = "upload[uploaded_file]";
  private static final String UPLOAD_URL_FILE_PART = "upload/save";
  private static final String UPLOAD_RESPONSE_URL_FILE_PART = "/upload/upload_ok";
  private static final String LOGIN_URL_FILE_PART = "login/login";
  private static final String STARTBUILD_URL_FILE_PART = "buildcontrol/start";
  private static final String BUILD_STARTED_RESPONSE_URL_FILE_PART = "buildcontrol/build_started";
  private static final String BUILD_NOT_STARTED_RESPONSE_URL_FILE_PART = "buildcontrol/build_not_started";
  private HttpClient client;
  private String baseUrl;
  private String user;
  private String password;

  private static URL getServerUrl() {
    URL result = null;
    try {
      return new URL( Activator.getDefault().getPluginPreferences().getString( "pluginbuilder.server" ) );
    } catch (MalformedURLException e) {
      Activator.log( e );
    }
    return result;
  }

  public static String getPassword(String user) {
    Map<String, String> authorizationInfo = Platform.getAuthorizationInfo( getServerUrl(), user, "" );
    if (authorizationInfo == null) {
      return null;
    }
    return authorizationInfo.get( user );
  }

  public static void setPassword(String user, String password) {
    Map<String, String> authorizationInfo = new HashMap<String, String>();
    if (user != null) {
      authorizationInfo.put( user, password );
    }
    try {
      Platform.addAuthorizationInfo( getServerUrl(), user, "", authorizationInfo );
    } catch (CoreException e) {
      Activator.log( e );
    }
  }

  public static void resetPassword(String user) {
    setPassword( user, null );
  }

  public ServerCommunication(String user, String password) throws IllegalArgumentException {
    setBaseUrl( Activator.getDefault().getPluginPreferences().getString( "pluginbuilder.server" ) );
    setUser( user );
    setPassword( password );
  }

  public ServerCommunication(String baseUrl, String user, String password) throws IllegalArgumentException {
    setBaseUrl( baseUrl );
    setUser( user );
    setPassword( password );
  }

  // protected String getUploadUrl() {
  // return baseUrl + "/" + UPLOAD_URL_FILE_PART;
  // }
  protected String getLoginUrl() {
    return baseUrl + "/" + LOGIN_URL_FILE_PART;
  }

  protected String getBuildControlUrl() {
    return baseUrl + "/" + STARTBUILD_URL_FILE_PART;
  }

  // public PostMethod createUploadMethod(File file, String path) {
  // assert file.exists();
  // String uploadUrl = getUploadUrl();
  // Activator.logDebug("Sending request to " + uploadUrl);
  // PostMethod filePost = new PostMethod(uploadUrl);
  // Part[] parts = new Part[2];
  // try {
  // parts[0] = new FilePart(UPLOAD_PART_NAME, path, file);
  // } catch (FileNotFoundException e) {
  // // ignore since file exists
  // }
  // parts[1] = new StringPart("upload[file_name]", path);
  // filePost.setRequestEntity(new MultipartRequestEntity(parts, filePost
  // .getParams()));
  // return filePost;
  // }
  protected PostMethod createLoginMethod(HttpMethodBase movedTemporarily) throws CommunicationException {
    assert movedTemporarily.hasBeenUsed();
    assert movedTemporarily.getStatusCode() == HttpStatus.SC_MOVED_TEMPORARILY;
    String loginUrl = extractNewUrl( movedTemporarily );
    if (loginUrl.indexOf( "login" ) == -1) {
      String message = "The uri " + loginUrl + " is not a expected login url.";
      throw new CommunicationException( message );
    }
    return createLoginMethod( loginUrl );
  }

  private String extractNewUrl(HttpMethodBase method) throws CommunicationException {
    assert method.hasBeenUsed();
    String result = null;
    if (method.getStatusCode() == HttpStatus.SC_MOVED_TEMPORARILY) {
      result = method.getResponseHeader( "Location" ).getValue();
      if (result == null) {
        String message = "The uri " + method.getQueryString() + " was moved temporarily but did not specify a location";
        throw new CommunicationException( message );
      }
    }
    return result;
  }

  private String getRedirectedPath(HttpMethodBase method) throws CommunicationException {
    String result = null;
    String url = extractNewUrl( method );
    if (url != null) {
      try {
        result = new URI( url ).getPath();
      } catch (URISyntaxException e) {
      }
    }
    return result;
  }

  protected PostMethod createLoginMethod(String loginUrl) {
    Activator.logInfo( "Login to server with user " + user );
    PostMethod login = new PostMethod( loginUrl );
    login.setParameter( "name", user );
    login.setParameter( "password", password );
    return login;
  }

  protected void login(PostMethod loginMethod) throws AuthenticationException, CommunicationException {
    try {
      int status = getClient().executeMethod( loginMethod );
      String redirect = extractNewUrl( loginMethod );
      // redirect occurs if there was an attempt to access a page before
      // but there was login yet, then the login redirects to the original
      // URL
      // if the authentication was successful
      // Also without a prior request there will be 302 after login
      if (redirect == null) {
        if (status == HttpStatus.SC_OK) {
          boolean failed = loginMethod.getResponseBodyAsString().indexOf( "Invalid user/password combination" ) != -1;
          if (failed) {
            resetPassword( user );
            throw new AuthenticationException( "User " + user + " could not login." );
          }
        } else {
          throw new AuthenticationException( "Login page returned unexpected Status: "
              + HttpStatus.getStatusText( status ) );
        }
      } else {
        try {
          Thread.sleep( 5000 );
        } catch (InterruptedException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        }
        Activator.logInfo( "Login Successful, redirected to " + redirect );
      }
    } catch (HttpException e) {
      throw new CommunicationException( e );
    } catch (IOException e) {
      throw new CommunicationException( e );
    }
  }

  public void login() throws AuthenticationException, CommunicationException {
    PostMethod loginMethod = createLoginMethod( getLoginUrl() );
    login( loginMethod );
  }

  // public void upload(File file, String path) throws CommunicationException,
  // AuthenticationException {
  // Activator.logInfo("Uploading " + file.getName() + " to " + path);
  // PostMethod postMethod = createUploadMethod(file, path);
  // try {
  // int status = getClient().executeMethod(postMethod);
  // status = loginIfRequested(postMethod, status);
  // String redirectedUrl = getRedirectedPath(postMethod);
  // if (redirectedUrl == null
  // || !redirectedUrl.equals(UPLOAD_RESPONSE_URL_FILE_PART)) {
  // String message = "Response status was "
  // + HttpStatus.getStatusText(status);
  // throw new CommunicationException(message);
  // }
  // } catch (Exception e) {
  // throw new CommunicationException(e);
  // }
  //
  // }
  private int loginIfRequested(PostMethod postMethod, int status) throws CommunicationException,
      AuthenticationException, IOException, HttpException {
    if (status == HttpStatus.SC_MOVED_TEMPORARILY && getRedirectedPath( postMethod ).contains( LOGIN_URL_FILE_PART )) {
      // login and retry
      PostMethod loginMethod = createLoginMethod( postMethod );
      login( loginMethod );
      status = getClient().executeMethod( postMethod );
    }
    return status;
  }

  public void startBuild(String buildVersion) throws CommunicationException, AuthenticationException {
    Activator.logInfo( "Attempting to trigger build..." );
    PostMethod postMethod = new PostMethod( getBuildControlUrl() );
    postMethod.setParameter( "build_version", buildVersion );
    try {
      int status = getClient().executeMethod( postMethod );
      status = loginIfRequested( postMethod, status );
      String redirectedUrl = getRedirectedPath( postMethod );
      if (redirectedUrl != null && redirectedUrl.contains( BUILD_STARTED_RESPONSE_URL_FILE_PART )) {
        Activator.logInfo( "Build was started. Check the build results on the server." );
      } else if (redirectedUrl != null && redirectedUrl.contains( BUILD_NOT_STARTED_RESPONSE_URL_FILE_PART )) {
        Activator
            .logInfo( "Build could not be started presumably because a build is still running. Check the build results on the server." );
      } else {
        String message = "Response status was " + HttpStatus.getStatusText( status );
        throw new CommunicationException( message );
      }
    } catch (Exception e) {
      throw new CommunicationException( e );
    }
  }

  private HttpClient getClient() {
    if (client == null) {
      client = new HttpClient();
      // client.getHttpConnectionManager().getParams().setConnectionTimeout(
      // 5000);
    }
    return client;
  }

  public String getBaseUrl() {
    return baseUrl;
  }

  public void setBaseUrl(String baseUrl) {
    if (baseUrl.endsWith( "/" )) {
      this.baseUrl = baseUrl.substring( 0, baseUrl.length() - 1 );
    } else {
      this.baseUrl = baseUrl;
    }
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    if (password == null || password.length() == 0) {
      throw new IllegalArgumentException( "Password must not be empty" );
    }
    this.password = password;
  }

  public String getUser() {
    return user;
  }

  public void setUser(String user) {
    if (user == null || user.length() == 0) {
      throw new IllegalArgumentException( "User must not be empty" );
    }
    this.user = user;
  }

  public void synchronize(File localDir) throws WebDavSyncException, WebDavAuthenticationException {
    String webdavUrl = Activator.getDefault().getPluginPreferences().getString( "pluginbuilder.server.webdav" );
    WebDavSynchronize webDavSynchronizer;
    try {
      webDavSynchronizer = new WebDavSynchronize( webdavUrl, getUser(), getPassword(), localDir );
      try {
        Pattern excludePattern = Pattern.compile( Activator.getDefault().getPluginPreferences().getString(
            "pluginbuilder.sync.exclusions" ) );
        webDavSynchronizer.setExcludePattern( excludePattern );
      } catch (IllegalArgumentException iax) {
        // includes PatternSyntaxException which is thrown from
        // Pattern.compile
        Activator.log( iax );
        Activator.logError( "Exclusion pattern could not be compiled." );
      }
    } catch (WebDavAuthenticationException e) {
      resetPassword( getUser() );
      throw e;
    }
    Activator.logInfo( "Connected to " + webdavUrl + ". Synchronizing..." );
    List<SyncCommand> createSyncCommands = webDavSynchronizer.createSyncCommands();
    for (SyncCommand syncCommand : createSyncCommands) {
      Activator.logInfo( syncCommand.description() );
      syncCommand.execute();
    }
    Activator.logInfo( "Finished." );
  }
}
