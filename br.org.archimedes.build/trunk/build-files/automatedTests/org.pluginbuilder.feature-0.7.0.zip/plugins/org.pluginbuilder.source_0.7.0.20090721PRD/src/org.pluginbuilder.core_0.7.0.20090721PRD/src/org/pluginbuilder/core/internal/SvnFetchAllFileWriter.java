/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.internal;

import java.io.IOException;
import java.io.Writer;
import java.text.MessageFormat;

import org.eclipse.core.resources.IProject;
import org.pluginbuilder.core.Activator;
import org.pluginbuilder.core.internal.subversion.ConfiguredSubversionAdapter;
import org.pluginbuilder.core.internal.subversion.SubversionAdapter;
import org.pluginbuilder.core.internal.subversion.SubversionAdapterFactory;
import org.pluginbuilder.core.internal.subversion.SubversionProviderAccessException;

public class SvnFetchAllFileWriter implements IPDEModelWriter {

  // example file content:
  // CVSMapFileWriter
  // <project name="Generated" default="noDefault">
  // <target name="fetch.svn.all">
  // <antcall target="svn.co">
  // <param name="element.id" value="org.pluginbuilder.ui"/>
  // <param name="target" value="plugins"/>
  // </antcall>
  // <antcall target="svn.co">
  // <param name="element.id" value="org.pluginbuilder.feature"/>
  // <param name="target" value="features"/>
  // </antcall>
  // </target>
  // </project>
  private final static String header = "<project name=\"Generated\">\n  <target name=\"fetch.svn.all\">\n";
  private final static String templateLine = "    <antcall target=\"svn.co\">\n      <param name=\"target\" value=\"{0}\"/>\n      <param name=\"element.id\" value=\"{1}\"/>\n      <param name=\"project.name\" value=\"{2}\"/>\n      <param name=\"url\" value=\"{3}\"/>\n    </antcall>";
  private final static String footer = "  </target>\n</project>";
  private Writer writer;
  private boolean isFirst = true;
  private final BuildConfig buildConfig;

  public SvnFetchAllFileWriter(Writer writer, BuildConfig buildConfig) {
    super();
    this.writer = writer;
    this.buildConfig = buildConfig;
  }

  public void writeFeature(String id, IProject project) throws IOException {
    write( "features", id, project );
  }

  public void writeFragment(String id, IProject project) throws IOException {
    write( "plugins", id, project );
  }

  public void writePlugin(String id, IProject project) throws IOException {
    write( "plugins", id, project );
  }

  private void write(String typ, String id, IProject project) throws IOException {
    if (isFirst) {
      isFirst = false;
      writer.write( header );
    }
    SubversionAdapter subversiveAdapter = SubversionAdapterFactory.createAdapter( project, buildConfig );
    String module;
    String root;
    try {
      module = subversiveAdapter.getRootRelativePath();
      root = subversiveAdapter.getRoot();
    } catch (SubversionProviderAccessException e) {
      Activator.getLogger()
          .info(
              "Error retrieving subversion information from " + project.getName()
                  + ". Falling back to configured SVN URL." );
      ConfiguredSubversionAdapter adapter = SubversionAdapterFactory.createConfiguredAdapter( project, buildConfig );
      module = adapter.getRootRelativePath();
      root = adapter.getRoot();
    }
    String line = MessageFormat.format( templateLine, new Object[] { typ, id, module, root } );
    writer.write( line );
    writer.write( "\n" );
  }

  public void finish() throws IOException {
    writer.write( footer );
    writer.flush();
    writer.close();
  }
}
