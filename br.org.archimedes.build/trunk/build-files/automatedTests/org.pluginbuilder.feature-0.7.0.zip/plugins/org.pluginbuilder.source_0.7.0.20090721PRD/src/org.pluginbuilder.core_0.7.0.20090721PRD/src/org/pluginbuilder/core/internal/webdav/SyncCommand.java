/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.internal.webdav;

import org.apache.webdav.lib.WebdavResource;

public abstract class SyncCommand {

  protected final WebdavResource resource;

  public SyncCommand(WebdavResource resource) {
    this.resource = resource;
  }

  public WebdavResource getResource() {
    return resource;
  }

  public abstract boolean execute() throws WebDavSyncException;

  public abstract String description();
}
