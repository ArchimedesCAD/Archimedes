/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.internal;

import java.io.IOException;

import org.eclipse.core.resources.IProject;

public interface IPDEModelWriter {

  void writePlugin(String id, IProject project) throws IOException;

  void writeFeature(String id, IProject project) throws IOException;

  void writeFragment(String id, IProject project) throws IOException;

  void finish() throws IOException;
}
