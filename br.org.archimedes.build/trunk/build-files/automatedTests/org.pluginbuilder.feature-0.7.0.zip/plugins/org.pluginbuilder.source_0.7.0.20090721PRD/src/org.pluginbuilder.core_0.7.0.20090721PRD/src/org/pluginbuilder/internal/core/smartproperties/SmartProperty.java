/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.internal.core.smartproperties;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SmartProperty {

  public enum SmartPropertyType {
    TEXT, ENUM, LIST, BOOLEAN, FILE, DIRECTORY
  }

  private String name;
  private String defaultValue;
  private String value;
  private final int defaultLineNo;
  private int valueLineNo;
  private String category;
  private String type;
  private String typeAttributes;
  private String documentation;

  public SmartProperty(final String name, String value, String defaultValue, int lineNo) {
    this.name = name;
    this.value = value;
    this.defaultValue = defaultValue;
    if (value != null) {
      if (defaultValue == null) {
        this.valueLineNo = lineNo;
        this.defaultLineNo = -1;
      } else {
        this.valueLineNo = lineNo + 1;
        this.defaultLineNo = lineNo;
      }
    } else {
      this.valueLineNo = -1;
      this.defaultLineNo = lineNo;
    }
  }

  public SmartProperty(final String name, String value, int lineNo) {
    this( name, value, null, lineNo );
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    if (value != null && defaultValue != null && value.equals( getDefaultValue() )) {
      this.value = null;
    } else {
      this.value = value;
    }
  }

  public String getName() {
    return name;
  }

  public String getDefaultValue() {
    return defaultValue;
  }

  public String getValueOrDefault() {
    return getValue() == null ? getDefaultValue() : getValue();
  }

  public void unset() {
    value = null;
  }

  protected void writeValue(List<String> lines) {
    if (valueLineNo == -1) {
      valueLineNo = defaultLineNo + 1;
    } else {
      lines.remove( valueLineNo );
    }
    if (getValue() == null) {
      return;
    }
    String assignment = getName() + "=" + getValue();
    lines.add( valueLineNo, assignment );
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public String getCategory() {
    return category;
  }

  public String getType() {
    return type;
  }

  public String getTypeAttributes() {
    return typeAttributes;
  }

  public void setTypeAttributes(String typeAttributes) {
    this.typeAttributes = typeAttributes;
  }

  public Map<String, String> getTypeAttributeMap() {
    Map<String, String> result = new HashMap<String, String>();
    if (typeAttributes == null) {
      return result;
    }
    String[] list = typeAttributes.split( "(?<=[^\\\\]);" );
    for (String entry : list) {
      String[] nameValue = entry.split( "(?<=[^\\\\])=" );
      if (nameValue.length == 1) {
        result.put( nameValue[0], "" );
      } else if (nameValue.length == 2) {
        String value = nameValue[1].replaceAll( "[\\\\];", ";" );
        value = value.replaceAll( "[\\\\]=", "=" );
        result.put( nameValue[0], value );
      }
    }
    return result;
  }

  public String getDocumentation() {
    return documentation;
  }

  public void setDocumentation(String documentation) {
    this.documentation = documentation;
  }

  public void setType(String type) {
    this.type = type;
  }

  public SmartPropertyType getTypeAsEnum() {
    if (type == null) {
      return SmartPropertyType.TEXT;
    }
    char typeId = type.toLowerCase().charAt( 0 );
    switch (typeId) {
    case 't':
      return SmartPropertyType.TEXT;
    case 'l':
      return SmartPropertyType.LIST;
    case 'b':
      return SmartPropertyType.BOOLEAN;
    case 'e':
      return SmartPropertyType.ENUM;
    case 'f':
      return SmartPropertyType.FILE;
    case 'd':
      return SmartPropertyType.DIRECTORY;

    default:
      return SmartPropertyType.TEXT;
    }
  }

  public void commitChange(SmartPropertyChange smartPropertyChange) {
    if (valueLineNo == -1) {
      valueLineNo = defaultLineNo + 1;
      if (getValue() != null) {
        smartPropertyChange.add( valueLineNo, getAssignment() );
      }
    } else {
      if (getValue() == null) {
        smartPropertyChange.remove( valueLineNo );
      } else {
        smartPropertyChange.update( valueLineNo, getAssignment() );
      }
    }
  }

  String getAssignment() {
    return getName() + "=" + getValue();
  }
}
