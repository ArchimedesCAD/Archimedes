/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.internal.core.serverconnection;

public class AuthenticationException extends Exception {

  public AuthenticationException() {
    super();
    // TODO Auto-generated constructor stub
  }

  public AuthenticationException(String message, Throwable cause) {
    super( message, cause );
    // TODO Auto-generated constructor stub
  }

  public AuthenticationException(String message) {
    super( message );
    // TODO Auto-generated constructor stub
  }

  public AuthenticationException(Throwable cause) {
    super( cause );
    // TODO Auto-generated constructor stub
  }
}
