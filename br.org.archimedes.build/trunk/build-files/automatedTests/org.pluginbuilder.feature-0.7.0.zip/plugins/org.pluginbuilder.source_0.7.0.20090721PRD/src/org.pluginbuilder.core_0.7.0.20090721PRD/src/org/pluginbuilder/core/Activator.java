/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core;

import java.lang.reflect.InvocationTargetException;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Plugin;
import org.eclipse.core.runtime.Status;
import org.osgi.framework.BundleContext;

/**
 * The activator class controls the plug-in life cycle
 */
public class Activator extends Plugin {

  // The plug-in ID
  public static final String PLUGIN_ID = "org.pluginbuilder.core";
  // The shared instance
  private static Activator plugin;

  /**
   * The constructor
   */
  public Activator() {
    plugin = this;
  }

  /*
   * (non-Javadoc)
   * 
   * @see org.eclipse.ui.plugin.AbstractUIPlugin#start(org.osgi.framework.BundleContext)
   */
  public void start(BundleContext context) throws Exception {
    super.start( context );
    // System.out.println(getPluginPreferences().getString(
    // "pluginbuilder.server"));
    turnOffLogging();
  }

  /*
   * (non-Javadoc)
   * 
   * @see org.eclipse.ui.plugin.AbstractUIPlugin#stop(org.osgi.framework.BundleContext)
   */
  public void stop(BundleContext context) throws Exception {
    plugin = null;
    super.stop( context );
  }

  public static String escapePath(String path) {
    return path.replaceAll( "[\\\\]+", "/" );
  }

  /**
   * Returns the shared instance
   * 
   * @return the shared instance
   */
  public static Activator getDefault() {
    return plugin;
  }

  public static String getPluginId() {
    return getDefault().getBundle().getSymbolicName();
  }

  public static void log(IStatus status) {
    ResourcesPlugin.getPlugin().getLog().log( status );
  }

  public static void log(Throwable e) {
    if (e instanceof InvocationTargetException)
      e = ((InvocationTargetException) e).getTargetException();
    IStatus status = null;
    if (e instanceof CoreException)
      status = ((CoreException) e).getStatus();
    else
      status = new Status( IStatus.ERROR, getPluginId(), IStatus.OK, e.getMessage() == null ? "null" : e.getMessage(),
          e );
    log( status );
  }

  public static void log(String message) {
    IStatus status = new Status( IStatus.INFO, getPluginId(), IStatus.OK, message, null );
    log( status );
  }

  public static IStatus createStatus(Exception inner) {
    String message = inner.getMessage() == null ? inner.getClass().getName() : inner.getMessage();
    return new Status( IStatus.ERROR, Activator.getPluginId(), IStatus.ERROR, message, inner );
  }

  public static CoreException createCoreException(Exception inner) {
    IStatus status = new Status( IStatus.ERROR, Activator.getPluginId(), IStatus.ERROR, inner.getMessage(), inner );
    return new CoreException( status );
  }

  public static CoreException createCoreException(String message) {
    IStatus status = new Status( IStatus.ERROR, Activator.getPluginId(), IStatus.ERROR, message, null );
    return new CoreException( status );
  }

  public static Logger getLogger() {
    return Logger.getLogger( "pluginbuilder.core" );
  }

  public static void logDebug(String message) {
    Activator.getLogger().log( Level.FINE, message );
  }

  public static void logInfo(String message) {
    Activator.getLogger().log( Level.INFO, message );
  }

  public static void logError(String message) {
    Activator.getLogger().log( Level.SEVERE, message );
  }

  public static void turnOffLogging() {
    // parent logs to stdout
    Logger parent = Activator.getLogger().getParent();
    if (parent != null) {
      removeAllHandlers( parent );
    }
    removeAllHandlers( getLogger() );
  }

  private static void removeAllHandlers(Logger logger) {
    Handler[] handlers = logger.getHandlers();
    for (int i = 0; i < handlers.length; i++) {
      handlers[i].close(); // flushes and closes outputstream as well
      logger.removeHandler( handlers[i] );
    }
  }
}
