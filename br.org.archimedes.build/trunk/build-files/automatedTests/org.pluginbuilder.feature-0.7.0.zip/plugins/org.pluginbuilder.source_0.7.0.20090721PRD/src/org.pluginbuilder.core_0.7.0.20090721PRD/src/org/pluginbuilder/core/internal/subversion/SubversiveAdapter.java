/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.internal.subversion;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.eclipse.team.core.RepositoryProvider;
import org.pluginbuilder.core.Activator;

public class SubversiveAdapter extends SubversionAdapter {

  private Object subversionProvider;

  public SubversiveAdapter(RepositoryProvider provider) {
    subversionProvider = provider;
  }

  private Object getRepositoryResource() throws IllegalArgumentException, IllegalAccessException,
      InvocationTargetException, SecurityException, NoSuchMethodException {
    Method method = subversionProvider.getClass().getMethod( "getRepositoryResource", new Class[] {} );
    return method.invoke( subversionProvider, new Object[] {} );
  }

  private String getRoot(Object repositoryResource) throws SecurityException, NoSuchMethodException,
      IllegalArgumentException, IllegalAccessException, InvocationTargetException {
    Method getRoot = repositoryResource.getClass().getMethod( "getRoot", new Class[] {} );
    Object root = getRoot.invoke( repositoryResource, new Object[] {} );
    Method getUrl = root.getClass().getMethod( "getUrl", new Class[] {} );
    return (String) getUrl.invoke( root, new Object[] {} );
  }

  private String getUrl(Object repositoryResource) throws SecurityException, NoSuchMethodException,
      IllegalArgumentException, IllegalAccessException, InvocationTargetException {
    Method getUrl = repositoryResource.getClass().getMethod( "getUrl", new Class[] {} );
    return (String) getUrl.invoke( repositoryResource, new Object[] {} );
  }

  public String getRootRelativePath() throws SubversionProviderAccessException {
    // RepositoryProvider provider = RepositoryProvider.getProvider( project
    // );
    // SVNTeamProvider svnProvider = ( SVNTeamProvider )provider;
    // System.out.println( svnProvider.getRepositoryLocation()
    // .getRepositoryRootUrl() );
    // System.out.println( svnProvider.getRepositoryLocation().getUsername()
    // );
    // System.out.println( svnProvider.getRepositoryLocation().getName() );
    // String root = svnProvider.getRepositoryResource().getRoot().getUrl();
    // String projectUrl = svnProvider.getRepositoryResource().getUrl();
    try {
      Object repositoryResource = getRepositoryResource();
      String root = getRoot( repositoryResource );
      String projectUrl = getUrl( repositoryResource );
      String module = null;
      if (projectUrl.startsWith( root )) {
        module = projectUrl.substring( root.length() );
      }
      return module;
    } catch (Exception e) {
      Activator.log( e );
      throw new SubversionProviderAccessException();
    }
  }

  public String getRoot() throws SubversionProviderAccessException {
    try {
      Object repositoryResource = getRepositoryResource();
      return getRoot( repositoryResource );
    } catch (Exception e) {
      Activator.log( e );
      throw new SubversionProviderAccessException();
    }
  }
}
