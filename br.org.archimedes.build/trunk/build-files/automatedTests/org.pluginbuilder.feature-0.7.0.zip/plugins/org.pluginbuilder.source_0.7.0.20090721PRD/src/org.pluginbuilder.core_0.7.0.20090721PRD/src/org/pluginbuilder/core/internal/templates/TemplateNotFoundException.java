/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.internal.templates;

public class TemplateNotFoundException extends Exception {

  public TemplateNotFoundException() {
    super();
    // TODO Auto-generated constructor stub
  }

  public TemplateNotFoundException(String message, Throwable cause) {
    super( message, cause );
    // TODO Auto-generated constructor stub
  }

  public TemplateNotFoundException(String message) {
    super( message );
    // TODO Auto-generated constructor stub
  }

  public TemplateNotFoundException(Throwable cause) {
    super( cause );
    // TODO Auto-generated constructor stub
  }
}
