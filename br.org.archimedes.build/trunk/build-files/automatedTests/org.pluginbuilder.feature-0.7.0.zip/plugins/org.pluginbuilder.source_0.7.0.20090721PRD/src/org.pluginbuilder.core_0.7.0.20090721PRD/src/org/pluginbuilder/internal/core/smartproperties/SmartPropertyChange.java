/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.internal.core.smartproperties;

import java.util.ArrayList;
import java.util.List;

public class SmartPropertyChange {

  abstract class Change {

    protected final int lineNo;
    protected final String value;

    public Change(int lineNo, String value) {
      this.lineNo = lineNo;
      this.value = value;
    }

    public abstract void execute();
  }

  class Removal extends Change {

    public Removal(int lineNo) {
      super( lineNo, null );
    }

    @Override
    public void execute() {
      lines.remove( lineNo );
    }
  }

  class Add extends Change {

    public Add(int lineNo, String value) {
      super( lineNo, value );
    }

    @Override
    public void execute() {
      lines.add( lineNo, value );
    }
  }

  private final List<String> lines;
  private List<Change> changes = new ArrayList<Change>();

  // private SortedMap<Integer, Change> changes = new TreeMap<Integer,
  // Change>();
  public SmartPropertyChange(List<String> lines) {
    this.lines = lines;
  }

  public void add(int lineNo, String assignment) {
    // changes.put( lineNo, new Add( lineNo, assignment ) );
    changes.add( new Add( lineNo, assignment ) );
  }

  public void remove(int lineNo) {
    changes.add( new Removal( lineNo ) );
  }

  public void update(int lineNo, String assignment) {
    lines.remove( lineNo );
    lines.add( lineNo, assignment );
  }

  public void commit() {
    for (Change change : changes) {
      change.execute();
    }
  }
}
