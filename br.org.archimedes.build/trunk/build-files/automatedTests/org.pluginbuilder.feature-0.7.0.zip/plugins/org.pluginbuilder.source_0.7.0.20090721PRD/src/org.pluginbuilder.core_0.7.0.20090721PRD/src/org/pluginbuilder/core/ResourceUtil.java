/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;

public class ResourceUtil {

  public static String getFileContent(final String projectName, final String path) throws CoreException {
    String result = null;
    IProject project = ResourcesPlugin.getWorkspace().getRoot().getProject( projectName );
    IPath p = new Path( path );
    IFile file = project.getFile( p );
    if (file.exists()) {
      InputStream inputStream = file.getContents();
      result = getContents( inputStream );
    }
    return result;
  }

  public static String getContents(final InputStream inputStream) throws CoreException {
    StringBuffer result = new StringBuffer();
    InputStreamReader reader = new InputStreamReader( inputStream );
    char[] buffer = new char[1000];
    try {
      int read = -1;
      while ((read = reader.read( buffer )) != -1) {
        result.append( buffer, 0, read );
      }
    } catch (IOException e) {
      // TODO
      String message = "Error reading file. " + e.getMessage();
      throw Activator.createCoreException( message );
    } finally {
      try {
        reader.close();
      } catch (IOException e) {
        Activator.log( e );
      }
    }
    return result.toString();
  }

  public static boolean createOrUpdateFile(final String projectName, final String path, final String content) {
    boolean result = ResourceUtil.createParentFolders( projectName, path );
    if (result) {
      IProject project = ResourcesPlugin.getWorkspace().getRoot().getProject( projectName );
      IPath p = new Path( path );
      IFile file = project.getFile( p );
      if (!file.exists()) {
        try {
          file.create( new ByteArrayInputStream( content.getBytes() ), true, new NullProgressMonitor() );
          result = file.exists();
        } catch (CoreException e) {
          result = false;
        }
      } else {
        try {
          file.setContents( new ByteArrayInputStream( content.getBytes() ), true, true, new NullProgressMonitor() );
        } catch (CoreException e) {
          Activator.log( e );
          result = false;
        }
      }
    }
    return result;
  }

  public static boolean createParentFolders(final IPath fullPath) {
    return createParentFolders( fullPath.segment( 0 ), fullPath.removeFirstSegments( 1 ).toPortableString() );
  }

  public static boolean createParentFolders(final String projectName, final String path) {
    boolean result = true;
    IProject project = ResourcesPlugin.getWorkspace().getRoot().getProject( projectName );
    IPath p = new Path( path );
    if (!project.getFile( p ).exists()) {
      // create folders recursively
      for (int i = 1; i < p.segmentCount(); i++) {
        IPath folder = p.uptoSegment( i );
        if (!project.exists( folder )) {
          try {
            project.getFolder( folder ).create( true, true, new NullProgressMonitor() );
          } catch (CoreException e) {
            result = false;
            break;
          }
        }
      }
    }
    return result;
  }
}
