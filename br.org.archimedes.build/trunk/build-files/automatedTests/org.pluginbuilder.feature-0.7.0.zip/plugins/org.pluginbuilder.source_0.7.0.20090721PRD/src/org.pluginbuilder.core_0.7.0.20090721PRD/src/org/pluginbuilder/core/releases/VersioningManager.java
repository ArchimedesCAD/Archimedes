/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.releases;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.FileLocator;
import org.pluginbuilder.core.Activator;
import org.pluginbuilder.core.internal.templates.Template;
import org.pluginbuilder.core.internal.templates.TemplateNotFoundException;

public class VersioningManager {

  private static final String DEFAULT_PROPERTIES_FILENAME = "release_default.properties";
  HashMap<String, NamedConfiguration> map;
  ArrayList<NamedConfiguration> deleted;
  private VersioningStore configurationStore;

  public VersioningManager(final VersioningStore configurationStore) {
    super();
    this.configurationStore = configurationStore;
    this.map = new HashMap<String, NamedConfiguration>();
    this.deleted = new ArrayList<NamedConfiguration>();
    try {
      load();
    } catch (IOException e) {
      Activator.log( e );
    } catch (CoreException cex) {
    }
  }

  public NamedConfiguration createNewConfiguration(final String id) throws FileNotFoundException, IOException,
      TemplateNotFoundException {
    NamedConfiguration namedConfiguration = new NamedConfiguration( id, createDefaultProperties() );
    map.put( id, namedConfiguration );
    return namedConfiguration;
  }
  
  private static File getTemplateDir() throws TemplateNotFoundException {
    URL entry = Activator.getDefault().getBundle().getEntry( Template.TEMPLATE_BASE_DIR.toString() );
    URL url;
    try {
      url = FileLocator.resolve( entry );
    } catch (IOException e) {
      throw new TemplateNotFoundException( e );
    }
    File templateDir = new File( url.getPath() );
    assert templateDir.exists();
    assert templateDir.isDirectory();
    return templateDir;
  }

  private Properties createDefaultProperties() throws FileNotFoundException, IOException, TemplateNotFoundException {
    File propertiesFile = new File( getTemplateDir(), DEFAULT_PROPERTIES_FILENAME );
    Properties properties = new Properties();
    properties.load( new FileInputStream( propertiesFile ) );
    return properties;
  }

  public void removeConfiguration(final NamedConfiguration configuration) {
    NamedConfiguration foundConfig = getConfiguration( configuration.getName() );
    if (foundConfig != null) {
      deleted.add( configuration );
      map.remove( configuration.getName() );
    }
  }

  public List<NamedConfiguration> getAllConfigurations() {
    List<NamedConfiguration> entries = new ArrayList<NamedConfiguration>();
    for (Iterator iter = map.entrySet().iterator(); iter.hasNext();) {
      Map.Entry entry = (Map.Entry) iter.next();
      entries.add( (NamedConfiguration) entry.getValue() );
    }
    return entries;
  }

  public NamedConfiguration getConfiguration(final String id) {
    return (NamedConfiguration) map.get( id );
  }

  public void save() throws IOException, CoreException {
    for (Iterator iter = map.keySet().iterator(); iter.hasNext();) {
      String id = (String) iter.next();
      NamedConfiguration namedConfiguration = map.get( id );
      if (namedConfiguration.isDirty()) {
        configurationStore.saveConfiguration( namedConfiguration );
      }
    }
    for (Iterator iter = deleted.iterator(); iter.hasNext();) {
      NamedConfiguration namedConfiguration = (NamedConfiguration) iter.next();
      configurationStore.deleteConfiguration( namedConfiguration );
      iter.remove();
    }
  }

  protected void load() throws IOException, CoreException {
    List<NamedConfiguration> configs = configurationStore.getAllConfigurations();
    for (Iterator iter = configs.iterator(); iter.hasNext();) {
      NamedConfiguration namedConfig = (NamedConfiguration) iter.next();
      map.put( namedConfig.getName(), namedConfig );
    }
  }

  public Object clone() throws CloneNotSupportedException {
    VersioningManager result = (VersioningManager) super.clone();
    result.deleted = CollectionUtil.deepClone( deleted );
    result.map = CollectionUtil.deepClone( map );
    return result;
  }
}
