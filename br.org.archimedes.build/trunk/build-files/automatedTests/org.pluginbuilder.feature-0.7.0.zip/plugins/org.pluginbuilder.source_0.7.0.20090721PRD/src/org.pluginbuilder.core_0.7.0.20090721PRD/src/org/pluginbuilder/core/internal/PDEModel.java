/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.internal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.pde.core.plugin.IPluginModelBase;
import org.eclipse.pde.internal.build.AbstractScriptGenerator;
import org.eclipse.pde.internal.build.IBuildPropertiesConstants;
import org.eclipse.pde.internal.build.IPDEBuildConstants;
import org.eclipse.pde.internal.core.FeatureModelManager;
import org.eclipse.pde.internal.core.PluginModelManager;
import org.eclipse.pde.internal.core.feature.WorkspaceFeatureModel;
import org.eclipse.pde.internal.core.ifeature.IFeature;
import org.eclipse.pde.internal.core.ifeature.IFeatureChild;
import org.eclipse.pde.internal.core.ifeature.IFeatureModel;
import org.eclipse.pde.internal.core.ifeature.IFeaturePlugin;
import org.pluginbuilder.core.Activator;

public class PDEModel {

  private PluginModelManager pluginModelManager;
  private FeatureModelManager featureModelManager;

  public PDEModel() {
    pluginModelManager = new PluginModelManager();
    featureModelManager = new FeatureModelManager();
  }

  public List<IFeature> getFeatures() {
    IFeatureModel[] featureModels = featureModelManager.getWorkspaceModels();
    List<IFeature> result = new ArrayList<IFeature>();
    for (int i = 0; i < featureModels.length; i++) {
      result.add( featureModels[i].getFeature() );
    }
    return result;
  }

  public IFeature findFeature(String name) {
    List<IFeature> features = getFeatures();
    for (IFeature feature : features) {
      if (feature.getId().equals( name )) {
        return feature;
      }
    }
    return null;
  }

  public void writeAllFeatures(IPDEModelWriter processor) throws IOException {
    writeFeatures( getFeatures(), processor );
  }

  public void writeFeatures(List<IFeature> features, IPDEModelWriter processor) throws IOException {
    for (IFeature feature : features) {
      writeFeature( feature, processor );
    }
    processor.finish();
  }

  public void writeFeature(IFeature feature, IPDEModelWriter processor) throws IOException {
    IProject project = feature.getModel().getUnderlyingResource().getProject();
    processor.writeFeature( feature.getId(), project );
    IFeaturePlugin[] plugins = feature.getPlugins();
    for (int i = 0; i < plugins.length; i++) {
      IFeaturePlugin currentPlugin = plugins[i];
      IPluginModelBase pluginModel = pluginModelManager.findModel( currentPlugin.getId() );
      if (pluginModel == null) {
        throw new UnsupportedOperationException( "plugin or fragment not found: " + currentPlugin.getId() );
      }
      if (pluginModel.getUnderlyingResource() == null) {
        // External Model
        Activator.logInfo( " skipping " + currentPlugin.getId() + " because it can not be found in the workspace" );
        continue;
      }
      project = pluginModel.getUnderlyingResource().getProject();
      if (currentPlugin.isFragment()) {
        processor.writeFragment( currentPlugin.getId(), project );
      } else {
        processor.writePlugin( currentPlugin.getId(), project );
      }
    }
    IFeatureChild[] includedFeatures = feature.getIncludedFeatures();
    for (int i = 0; i < includedFeatures.length; i++) {
      IFeatureChild included = includedFeatures[i];
      String id = included.getId();
      IFeature includedFeature = findFeature( id );
      if (includedFeature == null) {
        if (!isSourceFeature( feature, id )) {
          // TODO: the feature could probably be outside the
          // workspace
      	  Activator.logInfo( "Included feature " + id + " not found. This is harmless if you only want to re-package binary plug-ins." );  
        }
      } else {
        writeFeature( includedFeature, processor );
      }
    }
  }

  public boolean isSourceFeature(IFeature parent, String generatedFeatureId) {
    boolean result = false;
    IResource file = parent.getModel().getUnderlyingResource();
    IFile buildFile = file.getParent().getFile( new Path( "build.properties" ) );
    try {
      Properties properties = AbstractScriptGenerator.readProperties( file.getParent().getLocation().toOSString(),
          IPDEBuildConstants.PROPERTIES_FILE, IStatus.WARNING );
      result = properties.containsKey( IBuildPropertiesConstants.GENERATION_SOURCE_FEATURE_PREFIX + generatedFeatureId );
    } catch (CoreException e) {
      Activator.log( e );
    }
    return result;
  }

  private IFeature createResourceModel(IFile featureFile) throws CoreException {
    WorkspaceFeatureModel model = new WorkspaceFeatureModel( featureFile );
    model.load();
    return model.getFeature();
  }
}
