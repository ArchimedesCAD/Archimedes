/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.internal.webdav;

import org.apache.webdav.lib.WebdavResource;

public class DeleteResource extends SyncCommand {

  public DeleteResource(WebdavResource resource) {
    super( resource );
  }

  @Override
  public boolean execute() throws WebDavSyncException {
    try {
      return resource.deleteMethod();
    } catch (Exception e) {
      throw new WebDavSyncException( e );
    }
  }

  @Override
  public String description() {
    return "Deleting " + resource.getPath();
  }
}
