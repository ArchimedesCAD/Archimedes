package org.pluginbuilder.core.internal.webdav;

public class WebDavSyncException extends Exception {

  /**
   * 
   */
  private static final long serialVersionUID = -8818256352876750026L;

  public WebDavSyncException(String message) {
    super( message );
  }

  public WebDavSyncException(Throwable cause) {
    super( cause );
  }
}
