/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.internal.subversion;

import java.lang.reflect.Method;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IProject;
import org.pluginbuilder.core.Activator;

public class SubclipseAdapter extends SubversionAdapter {

  private final IProject project;
  private final ClassLoader sublipseProviderClassLoader;

  public SubclipseAdapter(IProject project, ClassLoader sublipseProviderClassLoader) {
    this.project = project;
    /*
     * ISVNLocalFolder subclipseFolder =
     * SVNWorkspaceRoot.getSVNFolderFor(project) ; subclipseFolder.getUrl() ;
     * subclipseFolder.getRepository().getRepositoryRoot().toString() ;
     */
    this.sublipseProviderClassLoader = sublipseProviderClassLoader;
  }

  @Override
  public String getRoot() throws SubversionProviderAccessException {
    try {
      Object svnFolder = getSvnFolder( project );
      Object repository = getRepository( svnFolder );
      Object repositoryRoot = getRepositoryRoot( repository );
      return (String) toString( repositoryRoot );
    } catch (Exception e) {
      Activator.log( e );
      Activator.getLogger().info( e.getMessage() );
      throw new SubversionProviderAccessException();
    }
  }

  @Override
  public String getRootRelativePath() throws SubversionProviderAccessException {
    String rootUrl = getRoot();
    String result;
    try {
      Object svnFolder = getSvnFolder( project );
      Object url = getUrl( svnFolder );
      result = (String) toString( url );
    } catch (Exception e) {
      throw new SubversionProviderAccessException();
    }
    if (result.startsWith( rootUrl )) {
      result = result.substring( rootUrl.length() );
    }
    return result;
  }

  private Object getSvnFolder(IProject project) throws Exception {
    Class<?> svnWorkspaceRoot = sublipseProviderClassLoader
        .loadClass( "org.tigris.subversion.subclipse.core.resources.SVNWorkspaceRoot" );
    Method method = svnWorkspaceRoot.getMethod( "getSVNFolderFor", new Class[] { IContainer.class } );
    return method.invoke( null, project );
  }

  private Object getUrl(Object svnFolder) throws Exception {
    Method getUrl = svnFolder.getClass().getMethod( "getUrl", new Class[] {} );
    return getUrl.invoke( svnFolder, new Object[] {} );
  }

  private Object getRepository(Object svnFolder) throws Exception {
    Method getRepository = svnFolder.getClass().getMethod( "getRepository", new Class[] {} );
    return getRepository.invoke( svnFolder, new Object[] {} );
  }

  private Object getRepositoryRoot(Object repository) throws Exception {
    Method getRepositoryRoot = repository.getClass().getMethod( "getRepositoryRoot", new Class[] {} );
    return getRepositoryRoot.invoke( repository, new Object[] {} );
  }

  private Object toString(Object obj) throws Exception {
    Method toString = obj.getClass().getMethod( "toString", new Class[] {} );
    return toString.invoke( obj, new Object[] {} );
  }
}
