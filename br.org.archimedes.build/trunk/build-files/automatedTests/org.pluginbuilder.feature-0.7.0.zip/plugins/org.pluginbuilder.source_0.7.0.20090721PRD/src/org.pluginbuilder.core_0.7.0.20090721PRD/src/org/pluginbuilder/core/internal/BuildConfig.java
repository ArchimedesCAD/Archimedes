/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.internal;

import java.util.ArrayList;
import java.util.List;

import org.pluginbuilder.autotestsuite.junit3.AllTestSuite;
import org.pluginbuilder.autotestsuite.junit3.AutoTestSuite;
import org.pluginbuilder.autotestsuite.junit3.InclusionFilter;
import org.pluginbuilder.internal.core.smartproperties.SmartProperties;

public class BuildConfig {

  public enum FetchMode {
    CVS, SVN, COPY, UNKNOWN
  }

  private FetchMode fetchMode = FetchMode.UNKNOWN;
  private boolean isAntVerbose = true;
  private boolean isRunTests = false;
  private boolean isGenerationNecessary = false;
  private InclusionFilter pluginInclusionFilter = new InclusionFilter( AllTestSuite.AUTOTEST_PLUGIN_DEFAULT_INCLUSIONS,
      AllTestSuite.AUTOTEST_PLUGIN_DEFAULT_EXCLUSIONS );
  private InclusionFilter testInclusionFilter = new InclusionFilter( AutoTestSuite.AUTOTEST_CLASS_INCLUSIONS,
      AutoTestSuite.AUTOTEST_CLASS_EXCLUSIONS );
  private String svnUrl;
  private String svnUser;
  private String svnPassword;
  private String testEclipseZip;
  private String eclipseUrl;
  private BuildLocalConfig buildLocalConfig;
  private List<String> features = new ArrayList<String>();
  private String serverUser;
  private SmartProperties buildProperties;
  private SmartProperties rcpBuildProperties;
  private SmartProperties testProperties;
  private boolean isRcpBuild = false;
  private List<String> featureUrls = new ArrayList<String>();
  private boolean isCoverageOn = false;
  private String coverageInclusionFilter;
  private String coverageExclusionFilter;

  public List<String> getFeatures() {
    return features;
  }

  public void setFeatures(List<String> features) {
    this.features = features;
  }

  public void addFeatures(List<String> newFeatures) {
    features.addAll( newFeatures );
  }

  public void removeFeatures(List<String> features) {
    features.removeAll( features );
  }

  public void removeFeature(String feature) {
    features.remove( feature );
  }

  public void addFeature(String newFeature) {
    features.add( newFeature );
  }

  public boolean isCVS() {
    return fetchMode == FetchMode.CVS;
  }

  public void setCVS() {
    this.fetchMode = FetchMode.CVS;
  }

  public boolean isSVN() {
    return fetchMode == FetchMode.SVN;
  }

  public void setSVN() {
    this.fetchMode = FetchMode.SVN;
  }

  public boolean isCopy() {
    return fetchMode == FetchMode.COPY;
  }

  public void setCopy() {
    this.fetchMode = FetchMode.COPY;
  }

  public FetchMode getFetchMode() {
    return this.fetchMode;
  }

  public String getSvnUrl() {
    return svnUrl;
  }

  public void setSvnUrl(String svnUrl) {
    this.svnUrl = svnUrl;
  }

  public void setServerUser(String serverUser) {
    this.serverUser = serverUser;
  }

  public String getServerUser() {
    return serverUser;
  }

  public boolean isAntVerbose() {
    return this.isAntVerbose;
  }

  public void setAntVerbose(boolean isAntVerbose) {
    this.isAntVerbose = isAntVerbose;
  }

  public BuildLocalConfig getBuildLocalConfig() {
    return buildLocalConfig;
  }

  public void setBuildLocalConfig(BuildLocalConfig buildLocalConfig) {
    this.buildLocalConfig = buildLocalConfig;
  }

  public String getSvnPassword() {
    return svnPassword;
  }

  public void setSvnPassword(String svnPassword) {
    this.svnPassword = svnPassword;
  }

  public String getSvnUser() {
    return svnUser;
  }

  public void setSvnUser(String svnUser) {
    this.svnUser = svnUser;
  }

  public boolean isRunTests() {
    return isRunTests;
  }

  public void setRunTests(boolean isRunTests) {
    this.isRunTests = isRunTests;
  }

  public InclusionFilter getPluginInclusionFilter() {
    return pluginInclusionFilter;
  }

  public void setPluginInclusionFilter(InclusionFilter pluginInclusionFilter) {
    this.pluginInclusionFilter = pluginInclusionFilter;
  }

  public InclusionFilter getTestInclusionFilter() {
    return testInclusionFilter;
  }

  public void setTestInclusionFilter(InclusionFilter testInclusionFilter) {
    this.testInclusionFilter = testInclusionFilter;
  }

  public String getTestEclipseZip() {
    return testEclipseZip;
  }

  public void setTestEclipseZip(String testEclipseHost) {
    this.testEclipseZip = testEclipseHost;
  }

  public String getEclipseUrl() {
    return eclipseUrl;
  }

  public void setEclipseUrl(String eclipseUrl) {
    this.eclipseUrl = eclipseUrl;
  }

  public void setBuildProperties(SmartProperties smartProperties) {
    this.buildProperties = smartProperties;
  }

  public SmartProperties getBuildProperties() {
    return buildProperties;
  }

  public void setRcpBuildProperties(SmartProperties smartProperties) {
    this.rcpBuildProperties = smartProperties;
  }

  public SmartProperties getRcpBuildProperties() {
    return rcpBuildProperties;
  }

  public void setRcpBuild(boolean isRcpBuild) {
    this.isRcpBuild = isRcpBuild;
  }

  public boolean isRcpBuild() {
    return isRcpBuild;
  }

  public List<String> getFeatureUrls() {
    return featureUrls;
  }

  public void addFeatureUrl(String url) {
    getFeatureUrls().add( url );
  }

  public void removeFeatureUrl(String url) {
    getFeatureUrls().remove( url );
  }

  public boolean isGenerationNecessary() {
    return isGenerationNecessary;
  }

  public void setGenerationNecessary(boolean isGenerationNecessary) {
    this.isGenerationNecessary = isGenerationNecessary;
  }

  public boolean isCoverageOn() {
    return isCoverageOn;
  }

  public void setCoverageOn(boolean isCoverageOn) {
    this.isCoverageOn = isCoverageOn;
  }

  public String getCoverageInclusionFilter() {
    return coverageInclusionFilter;
  }

  public void setCoverageInclusionFilter(String coverageInclusionFilter) {
    this.coverageInclusionFilter = coverageInclusionFilter;
  }

  public String getCoverageExclusionFilter() {
    return coverageExclusionFilter;
  }

  public void setCoverageExclusionFilter(String coverageExclusionFilter) {
    this.coverageExclusionFilter = coverageExclusionFilter;
  }

  public SmartProperties getTestProperties() {
    return testProperties;
  }

  public void setTestProperties(SmartProperties testBuildProperties) {
    this.testProperties = testBuildProperties;
  }
}
