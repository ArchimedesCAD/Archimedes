/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.internal.core.generator;

import java.util.logging.Level;

import org.eclipse.core.resources.IProject;
import org.pluginbuilder.core.Activator;
import org.pluginbuilder.core.ResourceUtil;
import org.pluginbuilder.core.internal.BuildConfig;
import org.pluginbuilder.core.internal.BuildConfigPersistency;
import org.pluginbuilder.core.internal.templates.TemplateNotFoundException;

public class BuildFileUpdate {

  private static final String FILE_FETCH_SVN_ALL = "build-files/fetchSvnAll.xml";
  private IProject project;
  private Generator generator;
  private BuildConfig config;

  public BuildFileUpdate(IProject project) {
    this.project = project;
    config = BuildConfigPersistency.read( project );
    this.generator = new Generator( config );
  }

  public void updateFiles() throws TemplateNotFoundException {
    if (config.isSVN()) {
      Activator.getLogger().log( Level.INFO, "Creating " + FILE_FETCH_SVN_ALL );
      String fetchSvnAllContent = generator.generateFetchSvnAll();
      ResourceUtil.createOrUpdateFile( project.getName(), FILE_FETCH_SVN_ALL, fetchSvnAllContent );
    } else {
      String mapFile = "maps/all.map";
      Activator.getLogger().log( Level.INFO, "Creating " + mapFile );
      String mapFileContent = generator.generateMapFile( config.isCVS() );
      ResourceUtil.createOrUpdateFile( project.getName(), mapFile, mapFileContent );
    }
    Activator.getLogger().log( Level.INFO, "Creating allElements.xml" );
    generator.createAllElements().write( project );
  }
}
