/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.core.releases;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Status;
import org.pluginbuilder.core.Activator;

public class VersioningStore {

  IFolder folder;

  public VersioningStore(IProject project) throws CoreException {
    folder = project.getFolder( new Path( "/releases" ) );
    if (!folder.exists()) {
      folder.create( true, true, new NullProgressMonitor() );
    }
  }

  public void saveConfiguration(final NamedConfiguration namedConfiguration) throws IOException, CoreException {
    IFile file = getPropertyFile( namedConfiguration );
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    String comments = "Written from Plug-in Builder Editor";
    namedConfiguration.getProperties().store( byteArrayOutputStream, comments );
    ByteArrayInputStream inputStream = new ByteArrayInputStream( byteArrayOutputStream.toByteArray() );
    file.setContents( inputStream, true, true, new NullProgressMonitor() );
  }

  public IFile getPropertyFile(final NamedConfiguration namedConfiguration) throws CoreException {
    String fileName = namedConfiguration.getName() + ".properties";
    IFile file = folder.getFile( fileName );
    if (!file.exists()) {
      file.create( new ByteArrayInputStream( new byte[] {} ), true, new NullProgressMonitor() );
    }
    return file;
  }

  public String getId(IResource file) {
    return file.getName().replaceAll( ".properties", "" );
  }

  public List<NamedConfiguration> getAllConfigurations() throws IOException, CoreException {
    final List<NamedConfiguration> configurations = new ArrayList<NamedConfiguration>();
    folder.accept( new IResourceVisitor() {

      public boolean visit(IResource resource) throws CoreException {
        boolean result = false;
        if (resource.equals( folder )) {
          result = true;
        } else if (resource.getName().endsWith( ".properties" )) {
          Properties properties = new Properties();
          InputStream contents = ((IFile) resource).getContents();
          try {
            properties.load( contents );
            contents.close();
          } catch (IOException e) {
            IStatus status = new Status( IStatus.ERROR, Activator.getPluginId(), IStatus.ERROR, e.getMessage(), e );
            throw new CoreException( status );
          }
          configurations.add( new NamedConfiguration( getId( resource ), properties ) );
        }
        return result;
      }
    } );
    return configurations;
  }

  public void deleteConfiguration(final NamedConfiguration namedConfiguration) throws IOException, CoreException {
    IFile file = getPropertyFile( namedConfiguration );
    file.delete( true, new NullProgressMonitor() );
  }
}
