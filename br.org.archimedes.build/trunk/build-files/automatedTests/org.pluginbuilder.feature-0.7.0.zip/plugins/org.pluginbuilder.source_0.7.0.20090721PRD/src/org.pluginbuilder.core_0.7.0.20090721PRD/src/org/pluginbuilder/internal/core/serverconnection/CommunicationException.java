/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.internal.core.serverconnection;

public class CommunicationException extends Exception {

  public CommunicationException() {
    // TODO Auto-generated constructor stub
  }

  public CommunicationException(String message) {
    super( message );
    // TODO Auto-generated constructor stub
  }

  public CommunicationException(Throwable cause) {
    super( cause );
    // TODO Auto-generated constructor stub
  }

  public CommunicationException(String message, Throwable cause) {
    super( message, cause );
    // TODO Auto-generated constructor stub
  }
}
