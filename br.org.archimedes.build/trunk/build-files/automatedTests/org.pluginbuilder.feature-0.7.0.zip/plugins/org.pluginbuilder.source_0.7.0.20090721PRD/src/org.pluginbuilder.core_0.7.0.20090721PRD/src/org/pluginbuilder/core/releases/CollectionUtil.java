/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld This program is distributed under the
 * Eclipse Public License v1.0 which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 ******************************************************************************/
package org.pluginbuilder.core.releases;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class CollectionUtil {

  public static ArrayList deepClone(final List original) {
    ArrayList result = new ArrayList();
    for (Iterator iter = original.iterator(); iter.hasNext();) {
      result.add( clone( iter.next() ) );
    }
    return result;
  }

  private static Object clone(final Object element) {
    Object clone = element;
    if (element instanceof Cloneable) {
      try {
        Method cloneMethod = element.getClass().getDeclaredMethod( "clone", new Class[] {} );
        if (cloneMethod != null) {
          clone = cloneMethod.invoke( element, new Object[] {} );
        }
      } catch (Exception ex) {
      }
    }
    return clone;
  }

  public static HashMap deepClone(final HashMap original) {
    HashMap result = new HashMap();
    for (Iterator iterKeys = original.keySet().iterator(); iterKeys.hasNext();) {
      Object element = iterKeys.next();
      result.put( element, clone( original.get( element ) ) );
    }
    return result;
  }

  public static void deserializeList(String source, List<String> target) {
    if (source != null) {
      String[] strings = source.split( "," );
      for (int i = 0; i < strings.length; i++) {
        target.add( strings[i].trim() );
      }
    }
  }

  public static String serializeList(List<String> source) {
    String list = "";
    for (String feature : source) {
      if (list.length() > 0) {
        list += ",";
      }
      list += feature;
    }
    return list;
  }
}
