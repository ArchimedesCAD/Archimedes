/*******************************************************************************
 * Copyright (c) 2007 Markus Barchfeld
 * This program is distributed under the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package org.pluginbuilder.internal.core.smartproperties;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.pluginbuilder.core.Activator;

public class SmartProperties {

  class NameValue {

    String name;
    String value;
    boolean isDefault;
  }

  class ParseContext {

    private String category;
    private String documentation;
    private String type;
    private String typeAttributes;

    void reset() {
      category = null;
      documentation = null;
      type = null;
      typeAttributes = null;
    }

    public String getCategory() {
      return category;
    }

    public void setCategory(String category) {
      this.category = category;
    }

    void updateParseContext(String line) {
      if (!line.startsWith( "#" )) {
        return;
      }
      String[] split = line.split( "@category" );
      if (split.length == 2) {
        category = split[1].trim();
        return;
      }
      int typeIndex = line.indexOf( "@type" );
      if (typeIndex != -1) {
        String typeInfo = line.substring( typeIndex + 5 ).trim();
        int spaceIndex = typeInfo.indexOf( " " );
        if (spaceIndex == -1) {
          type = typeInfo;
        } else {
          type = typeInfo.substring( 0, spaceIndex );
          typeAttributes = typeInfo.substring( spaceIndex + 1 );
        }
        return;
      }
      String docLine = line.substring( 1 ).trim();
      if (documentation == null) {
        documentation = docLine;
      } else {
        documentation += " " + docLine;
      }
    }

    void setParseContextValues(SmartProperty smartProperty) {
      smartProperty.setCategory( getCategory() );
      smartProperty.setDocumentation( documentation );
      smartProperty.setType( type );
      smartProperty.setTypeAttributes( typeAttributes );
      reset();
    }
  }

  private List<SmartProperty> properties;
  private List<String> lines;

  public SmartProperties(String string) {
    try {
      lines = parse( new ByteArrayInputStream( string.getBytes() ) );
      properties = createProperties( lines );
    } catch (IOException e) {
      Activator.log( e );
    }
  }

  public SmartProperties(InputStream contents) throws IOException {
    initialize( contents );
  }

  private void initialize(InputStream contents) throws IOException {
    lines = parse( contents );
    properties = createProperties( lines );
  }
  
  /**
   * Appends an uncategorized property to the end of the list. It will
   * appear at the end of the resulting stream (and, eventually, the 
   * associated properties file) when {@link #write(ByteArrayOutputStream)}
   * is called.  
   * 
   * @param name
   * @param value
   * @return true (always)
   */
  public boolean appendProperty(String name, String value) {
	final SmartProperty property = new SmartProperty(name, value, lines.size());
    lines.add(property.getAssignment());
    properties.add(property);
    return true;
  }
  
  public List<SmartProperty> getAllProperties() {
    return properties;
  }

  public SmartProperty getPropertyByName(String name) {
    for (Iterator<SmartProperty> iterator = properties.iterator(); iterator.hasNext();) {
      SmartProperty smartProp = iterator.next();
      if (smartProp.getName() != null && smartProp.getName().equals( name )) {
        return smartProp;
      }
    }
    return null;
  }

  public List<SmartProperty> getPropertiesByCategory(String category) {
    List<SmartProperty> result = new ArrayList<SmartProperty>();
    for (SmartProperty smartProperty : properties) {
      boolean addIfNull = category == null && smartProperty.getCategory() == null;
      boolean addIfNotNull = category != null && smartProperty.getCategory() != null
          && category.equals( smartProperty.getCategory() );
      if (addIfNull || addIfNotNull) {
        result.add( smartProperty );
      }
    }
    return result;
  }

  public List<SmartProperty> getUncategorizedProperties() {
    return getPropertiesByCategory( null );
  }

  private List<String> parse(InputStream stream) throws IOException {
    BufferedReader reader = new BufferedReader( new InputStreamReader( stream ) );
    String line = null;
    List<String> lines = new ArrayList<String>();
    while ((line = reader.readLine()) != null) {
      lines.add( line );
    }
    return lines;
  }

  private List<SmartProperty> createProperties(List<String> lines) {
    List<SmartProperty> properties = new ArrayList<SmartProperty>();
    ParseContext parseContext = new ParseContext();
    for (int i = 0; i < lines.size(); i++) {
      String line = lines.get( i );
      SmartProperty smartProperty = null;
      NameValue extractedNameValue = extractNameValue( line );
      if (extractedNameValue == null) {
        parseContext.updateParseContext( line );
        continue;
      }
      if (extractedNameValue.isDefault) {
        if (i < lines.size() - 1) {
          NameValue nameValue = extractNameValue( lines.get( i + 1 ) );
          if (nameValue != null && !nameValue.isDefault && nameValue.name.equals( extractedNameValue.name )) {
            smartProperty = new SmartProperty( extractedNameValue.name, nameValue.value, extractedNameValue.value, i );
            i += 1;
          }
        }
        // a value could not be found
        if (smartProperty == null) {
          smartProperty = new SmartProperty( extractedNameValue.name, null, extractedNameValue.value, i );
        }
      } else {
        smartProperty = new SmartProperty( extractedNameValue.name, extractedNameValue.value, i );
      }
      properties.add( smartProperty );
      parseContext.setParseContextValues( smartProperty );
    }
    return properties;
  }

  private NameValue extractNameValue(String line) {
    if (line.endsWith( "=" )) {
      line = line + " ";
    }
    String[] nameValue = line.split( "(?<!\\\\)=" );
    if (nameValue.length != 2) {
      return null;
    }
    NameValue result = new NameValue();
    ;
    if (nameValue[0].startsWith( "#" )) {
      result.name = nameValue[0].substring( 1 ).trim();
      if (result.name.indexOf( " " ) != -1) {
        return null;
      }
      result.isDefault = true;
    } else {
      result.name = nameValue[0].trim();
      result.isDefault = false;
    }
    result.value = nameValue[1].trim();
    return result;
  }

  public void write(ByteArrayOutputStream output) throws IOException {
    SmartPropertyChange smartPropertyChange = new SmartPropertyChange( lines );
    for (int i = properties.size() - 1; i >= 0; i--) {
      properties.get( i ).commitChange( smartPropertyChange );
    }
    smartPropertyChange.commit();
    StringBuffer sb = new StringBuffer();
    String nw = System.getProperty( "line.separator", "\n" );
    for (int i = 0; i < lines.size(); i += 1) {
      sb.append( lines.get( i ) );
      if (i != lines.size() - 1) {
        sb.append( nw );
      }
    }
    output.write( sb.toString().getBytes() );
    initialize( new ByteArrayInputStream( sb.toString().getBytes() ) );
  }
}
