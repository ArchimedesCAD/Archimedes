/*
 * Copyright (c) 2003-2007 OFFIS, Henri Tremblay. 
 * This program is made available under the terms of the MIT License.
 */
package org.easymock.classextension.tests;

import org.easymock.classextension.tests2.*;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses(value = {

        // Libraries usage
        CglibTest.class,

        // Easymock 1 tests
        MockClassControlTest.class, ConstructorTest.class, MockingTest.class,
        DefaultClassInstantiatorTest.class, LimitationsTest.class,
        ClassInstantiatorFactoryTest.class,

        // Easymock 2 tests
        ClassExtensionHelperTest.class, EasyMockClassExtensionTest.class,
        GenericTest.class, ConstructorArgsTest.class, PartialMockingTest.class, MocksControlTest.class })
public class AllTests {
}